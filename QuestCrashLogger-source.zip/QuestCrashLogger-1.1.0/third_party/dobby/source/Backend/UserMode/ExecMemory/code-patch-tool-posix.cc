
#include "dobby/dobby_internal.h"
#include "PlatformUnifiedInterface/ExecMemory/ClearCacheTool.h"

#include <unistd.h>
#include <sys/mman.h>
#include <string.h>

#if !defined(__APPLE__)
PUBLIC int DobbyCodePatch(void *address, uint8_t *buffer, uint32_t buffer_size) {
#if defined(__ANDROID__) || defined(__linux__)
  if (!address || !buffer || !buffer_size)
    return -1;
  int page_size = (int)sysconf(_SC_PAGESIZE);
  uintptr_t patch_page = ALIGN_FLOOR(address, page_size);
  uintptr_t patch_end_page = ALIGN_FLOOR((uintptr_t)address + buffer_size - 1, page_size);
  size_t patch_size = patch_end_page - patch_page + page_size;

  // change page permission as rwx
  // QCL: fail before writing if a device refuses to make code writable.
  if (mprotect((void *)patch_page, patch_size, PROT_READ | PROT_WRITE | PROT_EXEC) != 0)
    return -1;

  // patch buffer
  memcpy(address, buffer, buffer_size);

  // restore page permission
  int restored = mprotect((void *)patch_page, patch_size, PROT_READ | PROT_EXEC);

  addr_t clear_start_ = (addr_t)address;
  ClearCache((void *)clear_start_, (void *)(clear_start_ + buffer_size));
  return restored == 0 ? 0 : -1;
#endif
  return 0;
}

#endif
