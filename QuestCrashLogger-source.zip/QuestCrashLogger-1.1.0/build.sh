#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
quest_ndk="${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}"
if [[ -z "$quest_ndk" || ! -f "$quest_ndk/build/cmake/android.toolchain.cmake" ]]; then
  echo 'Set ANDROID_NDK_HOME to an extracted Android NDK (r27 or newer recommended).' >&2
  exit 1
fi
cmake -S "$project_dir" -B "$project_dir/build/arm64-v8a" -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$quest_ndk/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-29 \
  -DANDROID_STL=c++_static -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DQCL_UNITY_VER="${QCL_UNITY_VER:-222}"
cmake --build "$project_dir/build/arm64-v8a" --target questcrashlogger --parallel "${JOBS:-4}"
mkdir -p "$project_dir/dist/arm64-v8a"
cp "$project_dir/build/arm64-v8a/libquestcrashlogger.so" "$project_dir/dist/arm64-v8a/libquestcrashlogger.debug.so"
quest_strip="$quest_ndk/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip"
if [[ ! -x "$quest_strip" ]]; then
  quest_strip="$(command -v llvm-strip)"
fi
"$quest_strip" --strip-unneeded \
  -o "$project_dir/dist/arm64-v8a/libquestcrashlogger.so" \
  "$project_dir/build/arm64-v8a/libquestcrashlogger.so"
printf 'Built %s\n' "$project_dir/dist/arm64-v8a/libquestcrashlogger.so"
