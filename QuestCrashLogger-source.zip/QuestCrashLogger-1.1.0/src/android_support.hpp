#pragma once
#include <jni.h>
#include <string>

namespace qcl {
jobject FindApplication(JNIEnv *env);
jobject RetainApplicationContext(JNIEnv *env, jobject context);
void SetLastError(const char *static_message);
const char *LastError();
bool InitializeFromContext(JNIEnv *env, jobject context, char *package_name, unsigned capacity);
bool PrepareDownloads(JNIEnv *env, jobject context, const char *package_name);
void CaptureLogcat();
std::string CaptureGameLog(int pid);
bool EnableUnityCapture(unsigned unity_header_version);
}
