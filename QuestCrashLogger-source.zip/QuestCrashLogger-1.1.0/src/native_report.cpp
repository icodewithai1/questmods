#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include "native_report.hpp"

#include <atomic>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <limits.h>
#include <link.h>
#ifdef __ANDROID__
#include <android/log.h>
#endif
#include <signal.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <time.h>
#include <ucontext.h>
#include <unistd.h>

namespace qcl {
namespace {
constexpr unsigned kSlots = 128;
constexpr unsigned kLineBytes = 4096;
constexpr int kSignals[] = {SIGSEGV, SIGABRT, SIGBUS, SIGILL, SIGFPE, SIGTRAP};
static_assert(std::atomic<unsigned>::is_always_lock_free);
static_assert(std::atomic<int>::is_always_lock_free);
static_assert(std::atomic<unsigned char>::is_always_lock_free);

struct Slot {
    std::atomic<unsigned> busy{0};
    std::atomic<unsigned> sequence{0};
    std::atomic<unsigned> length{0};
    unsigned char bytes[kLineBytes]{};
};
constinit Slot g_slots[kSlots];
constinit std::atomic<unsigned> g_cursor{0};
constinit std::atomic<int> g_private_fd{-1};
constinit std::atomic<int> g_download_fd{-1};
constinit std::atomic<int> g_receipt_fd{-1};
constinit std::atomic<int> g_handling{0};
constinit std::atomic<int> g_ready{0};
constinit std::atomic<bool> g_signals_armed{false};
char g_path[PATH_MAX]{};
char g_directory[PATH_MAX]{};
struct sigaction g_previous[sizeof(kSignals) / sizeof(kSignals[0])]{};
alignas(16) unsigned char g_alt_stack[64 * 1024]{};

bool WriteAll(int fd, const char *data, std::size_t length) {
    if (fd < 0) return false;
    while (length) {
        const ssize_t n = write(fd, data, length);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) return false;
        data += n;
        length -= static_cast<std::size_t>(n);
    }
    return true;
}

/* Used in the signal handler: fixed storage, no formatting library or heap. */
template<std::size_t N> struct Buffer {
    char bytes[N]{};
    std::size_t size{};
    void Text(const char *s) {
        while (*s && size < N) bytes[size++] = *s++;
    }
    void Unsigned(std::uint64_t value, unsigned base = 10) {
        char reversed[32];
        unsigned count = 0;
        do {
            reversed[count++] = "0123456789abcdef"[value % base];
            value /= base;
        } while (value && count < sizeof(reversed));
        while (count && size < N) bytes[size++] = reversed[--count];
    }
    void Signed(int value) {
        if (value < 0) {
            Text("-");
            Unsigned(static_cast<std::uint64_t>(-static_cast<std::int64_t>(value)));
        } else Unsigned(static_cast<unsigned>(value));
    }
    void Register(const char *label, std::uint64_t value) {
        Text(label);
        Text("=0x");
        Unsigned(value, 16);
        Text("\n");
    }
};

struct Destination {
    int local;
    int downloads;
    bool downloads_ok;
    void Write(const char *data, std::size_t length) {
        WriteAll(local, data, length);
        if (downloads >= 0 && !WriteAll(downloads, data, length)) downloads_ok = false;
    }
    template<std::size_t N> void Literal(const char (&text)[N]) { Write(text, N - 1); }
};

void DumpLogs(Destination &out) {
    out.Literal("\nGame logs:\n");
    const unsigned end = g_cursor.load(std::memory_order_acquire);
    const unsigned start = end > kSlots ? end - kSlots : 0;
    char line[kLineBytes];
    for (unsigned index = start; index < end; ++index) {
        Slot &slot = g_slots[index % kSlots];
        if (slot.busy.load(std::memory_order_acquire)) continue;
        const unsigned sequence = slot.sequence.load(std::memory_order_acquire);
        if (sequence != index + 1) continue;
        unsigned length = slot.length.load(std::memory_order_relaxed);
        if (length > kLineBytes) continue;
        for (unsigned j = 0; j < length; ++j)
            line[j] = static_cast<char>(__atomic_load_n(&slot.bytes[j], __ATOMIC_RELAXED));
        std::atomic_thread_fence(std::memory_order_acquire);
        if (slot.busy.load(std::memory_order_acquire) ||
            slot.sequence.load(std::memory_order_acquire) != sequence) continue;
        out.Write(line, length);
        out.Literal("\n");
    }
}

/* Only POD/lock-free operations below are reachable from the signal handler. */
constexpr unsigned kModules = 192;
struct Module {
    unsigned sequence{};
    std::uintptr_t begin{}, end{}, base{};
    unsigned char name[160]{};
};
constinit Module g_modules[kModules]{};
constinit std::atomic<unsigned> g_module_count{0};
constinit std::atomic_flag g_refreshing = ATOMIC_FLAG_INIT;
constinit std::atomic<int> g_mem_fd{-1};
char g_package[256] = "unknown";

int CacheModule(dl_phdr_info *info, std::size_t, void *opaque) {
    auto &count = *static_cast<unsigned *>(opaque);
    if (count >= kModules) return 1;
    std::uintptr_t begin = UINTPTR_MAX, end = 0;
    for (unsigned i = 0; i < info->dlpi_phnum; ++i) {
        const auto &p = info->dlpi_phdr[i];
        if (p.p_type != PT_LOAD) continue;
        const auto start = static_cast<std::uintptr_t>(info->dlpi_addr + p.p_vaddr);
        if (start < begin) begin = start;
        if (start + p.p_memsz > end) end = start + p.p_memsz;
    }
    if (!end || begin == UINTPTR_MAX) return 0;
    const char *name = info->dlpi_name;
    if (!name || !*name) name = "[game executable]";
    if (const char *slash = std::strrchr(name, '/')) name = slash + 1;
    Module &module = g_modules[count++];
    const unsigned old = __atomic_load_n(&module.sequence, __ATOMIC_RELAXED);
    __atomic_store_n(&module.sequence, old + 1, __ATOMIC_RELEASE);
    __atomic_store_n(&module.begin, begin, __ATOMIC_RELAXED);
    __atomic_store_n(&module.end, end, __ATOMIC_RELAXED);
    __atomic_store_n(&module.base, static_cast<std::uintptr_t>(info->dlpi_addr), __ATOMIC_RELAXED);
    unsigned n = 0;
    while (name[n] && n + 1 < sizeof(module.name)) {
        __atomic_store_n(&module.name[n], static_cast<unsigned char>(name[n]), __ATOMIC_RELAXED);
        ++n;
    }
    __atomic_store_n(&module.name[n], static_cast<unsigned char>(0), __ATOMIC_RELAXED);
    __atomic_store_n(&module.sequence, old + 2, __ATOMIC_RELEASE);
    return 0;
}

void Frame(Destination &out, unsigned index, std::uintptr_t pc) {
    Buffer<512> b;
    b.Text("  #");
    if (index < 10) b.Text("0");
    b.Unsigned(index);
    b.Text(" pc 0x");
    bool found = false;
    const std::uintptr_t candidates[] = {pc, pc & 0x00ffffffffffffffULL, pc & 0x0000ffffffffffffULL};
    const unsigned count = g_module_count.load(std::memory_order_acquire);
    for (unsigned i = 0; i < count && !found; ++i) {
        Module &m = g_modules[i];
        const unsigned sequence = __atomic_load_n(&m.sequence, __ATOMIC_ACQUIRE);
        if (sequence & 1) continue;
        const auto begin = __atomic_load_n(&m.begin, __ATOMIC_RELAXED);
        const auto end = __atomic_load_n(&m.end, __ATOMIC_RELAXED);
        const auto base = __atomic_load_n(&m.base, __ATOMIC_RELAXED);
        for (auto address : candidates) {
            if (address < begin || address >= end) continue;
            char name[160];
            unsigned n = 0;
            do {
                name[n] = static_cast<char>(__atomic_load_n(&m.name[n], __ATOMIC_RELAXED));
            } while (name[n] && ++n + 1 < sizeof(name));
            name[sizeof(name) - 1] = 0;
            if (__atomic_load_n(&m.sequence, __ATOMIC_ACQUIRE) != sequence) break;
            b.Unsigned(address - base, 16);
            b.Text(" "); b.Text(name); b.Text("\n");
            found = true;
            break;
        }
    }
    if (!found) { b.Unsigned(pc, 16); b.Text(" [unresolved address]\n"); }
    out.Write(b.bytes, b.size);
}

void DumpStack(Destination &out, void *context) {
    out.Literal("\nNative stack:\n");
    if (!context) { out.Literal("  CPU context unavailable.\n"); return; }
    const auto *uc = static_cast<const ucontext_t *>(context);
    std::uintptr_t pc = 0, fp = 0, lr = 0;
#if defined(__aarch64__)
    pc = uc->uc_mcontext.pc;
    fp = uc->uc_mcontext.regs[29] & 0x00ffffffffffffffULL;
    lr = uc->uc_mcontext.regs[30];
    constexpr unsigned adjustment = 4;
#elif defined(__x86_64__)
    pc = uc->uc_mcontext.gregs[REG_RIP];
    fp = uc->uc_mcontext.gregs[REG_RBP];
    constexpr unsigned adjustment = 1;
#else
    constexpr unsigned adjustment = 0;
#endif
    unsigned depth = 0;
    Frame(out, depth++, pc);
    std::uintptr_t previous_pc = pc;
    if (lr > adjustment) { Frame(out, depth++, lr - adjustment); previous_pc = lr; }
    const int mem = g_mem_fd.load(std::memory_order_relaxed);
    while (mem >= 0 && fp && depth < 24 && !(fp % sizeof(std::uintptr_t))) {
        std::uintptr_t pair[2]{};
        if (pread(mem, pair, sizeof(pair), static_cast<off_t>(fp)) != sizeof(pair)) break;
        if (pair[1] > adjustment && pair[1] != previous_pc) {
            Frame(out, depth++, pair[1] - adjustment);
            previous_pc = pair[1];
        }
        if (pair[0] <= fp || pair[0] - fp > 1024 * 1024) break;
        fp = pair[0];
    }
}

const char *SignalName(int signal) {
    switch (signal) {
        case SIGSEGV: return "SIGSEGV";
        case SIGABRT: return "SIGABRT";
        case SIGBUS: return "SIGBUS";
        case SIGILL: return "SIGILL";
        case SIGFPE: return "SIGFPE";
        case SIGTRAP: return "SIGTRAP";
        default: return "unknown signal";
    }
}
const char *SignalReason(int signal, const siginfo_t *info) {
    if (signal != SIGABRT && info && info->si_code <= 0)
        return "Signal raised by the process or another sender";
    switch (signal) {
        case SIGSEGV:
            if (info && info->si_code > 0 && reinterpret_cast<std::uintptr_t>(info->si_addr) < 4096)
                return "Likely null pointer access";
            if (info && info->si_code == SEGV_ACCERR) return "Memory access permission violation";
            return "Invalid memory access";
        case SIGABRT: return "Process aborted; check the game log for an exception or assertion";
        case SIGBUS: return "Invalid or misaligned memory access";
        case SIGILL: return "Invalid CPU instruction";
        case SIGFPE: return "Invalid arithmetic operation";
        case SIGTRAP: return "Trap or breakpoint";
        default: return "Fatal process signal";
    }
}

void ForwardSignal(int signal, siginfo_t *info) {
    unsigned index = 0;
    while (index < sizeof(kSignals) / sizeof(kSignals[0]) && kSignals[index] != signal) ++index;
    if (index == sizeof(kSignals) / sizeof(kSignals[0])) _exit(128 + signal);
    struct sigaction previous = g_previous[index];
    if (previous.sa_handler == SIG_IGN && (!info || info->si_code <= 0)) {
        sigaction(signal, &previous, nullptr);
        return;
    }
    if (previous.sa_handler == SIG_IGN) {
        previous.sa_handler = SIG_DFL;
        previous.sa_flags = 0;
    }
    if (sigaction(signal, &previous, nullptr) != 0) _exit(128 + signal);
    /* Retrying a synchronous fault preserves its original siginfo/ucontext for
     * Android's handler, including the original fault address. */
    if (info && info->si_code > 0 &&
        (signal == SIGSEGV || signal == SIGBUS || signal == SIGILL || signal == SIGFPE))
        return;
    /* A raised signal and a breakpoint might not recur on return. Queue it for
     * the original handler; it is delivered after this handler unblocks it. */
    if (syscall(SYS_tgkill, getpid(), syscall(SYS_gettid), signal) != 0)
        _exit(128 + signal);
}

void SignalHandler(int signal, siginfo_t *info, void *context) {
    const int saved_errno = errno;
    for (unsigned i = 0; i < sizeof(kSignals) / sizeof(kSignals[0]); ++i) {
        if (kSignals[i] == signal && g_previous[i].sa_handler == SIG_IGN &&
            (!info || info->si_code <= 0)) {
            ForwardSignal(signal, info);
            errno = saved_errno;
            return;
        }
    }
    if (g_handling.exchange(1, std::memory_order_acq_rel)) {
        ForwardSignal(signal, info);
        errno = saved_errno;
        return;
    }
    Destination out{g_private_fd.load(std::memory_order_relaxed),
                    g_download_fd.load(std::memory_order_relaxed), true};
    Buffer<4096> b;
    timespec now{};
    clock_gettime(CLOCK_REALTIME, &now);
    b.Text("\n=== QCL_NATIVE_CRASH ===\nGame crash\nProcess: ");
    b.Text(g_package);
    b.Text("\nTime (Unix seconds): "); b.Unsigned(static_cast<std::uint64_t>(now.tv_sec));
    b.Text("\nPID: "); b.Unsigned(static_cast<std::uint64_t>(getpid()));
    b.Text("\nThread: "); b.Unsigned(static_cast<std::uint64_t>(syscall(SYS_gettid)));
    b.Text("\nCrash: "); b.Text(SignalName(signal));
    b.Text("\nReason: "); b.Text(SignalReason(signal, info));
    b.Text("\nSignal code: "); b.Signed(info ? info->si_code : 0); b.Text("\n");
    if (info && info->si_code > 0 && signal != SIGABRT)
        b.Register("Fault address", reinterpret_cast<std::uintptr_t>(info->si_addr));
    out.Write(b.bytes, b.size);
    DumpStack(out, context);
    DumpLogs(out);
    out.Literal("\n=== END QCL_NATIVE_CRASH ===\n");
    if (out.local >= 0) fsync(out.local);
    if (out.downloads >= 0 && out.downloads_ok && fsync(out.downloads) == 0) {
        const int receipt = g_receipt_fd.load(std::memory_order_relaxed);
        if (receipt >= 0) {
            WriteAll(receipt, "1", 1);
            fsync(receipt);
        }
    }
    g_handling.store(0, std::memory_order_release);
    ForwardSignal(signal, info);
    errno = saved_errno;
}
} // namespace

bool InitializeNative(const char *directory, const char *package_name, bool arm_signals) {
    if (g_ready.load(std::memory_order_acquire)) {
        if (arm_signals) ArmNativeHandlers();
        return true;
    }
    if (!directory || std::strlen(directory) > PATH_MAX - 160) return false;
    if (mkdir(directory, 0700) != 0 && errno != EEXIST) return false;
    timespec now{};
    clock_gettime(CLOCK_REALTIME, &now);
    std::snprintf(g_path, sizeof(g_path), "%s/QuestCrash-%lld-%09ld-%d.txt",
                  directory, static_cast<long long>(now.tv_sec), now.tv_nsec, getpid());
    int fd = open(g_path, O_WRONLY | O_CREAT | O_EXCL | O_APPEND | O_CLOEXEC, 0600);
    if (fd < 0) return false;
    std::snprintf(g_directory, sizeof(g_directory), "%s", directory);
    char receipt[PATH_MAX + 16];
    std::snprintf(receipt, sizeof(receipt), "%s.delivered", g_path);
    g_receipt_fd.store(open(receipt, O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0600));
    g_private_fd.store(fd, std::memory_order_release);
    std::snprintf(g_package, sizeof(g_package), "%s", package_name ? package_name : "unknown");
    g_mem_fd.store(open("/proc/self/mem", O_RDONLY | O_CLOEXEC), std::memory_order_release);
    char header[512];
    const int n = std::snprintf(header, sizeof(header),
        "QCL private session\nProcess: %s\nPID: %d\n", g_package, getpid());
    WriteAll(fd, header, static_cast<std::size_t>(n));
    g_ready.store(1, std::memory_order_release);
    if (arm_signals) ArmNativeHandlers();
    return true;
}

void ArmNativeHandlers() {
    if (!NativeReady() || g_signals_armed.exchange(true, std::memory_order_acq_rel)) return;
    stack_t old_stack{};
    if (sigaltstack(nullptr, &old_stack) == 0 && (old_stack.ss_flags & SS_DISABLE)) {
        stack_t alternate{};
        alternate.ss_sp = g_alt_stack;
        alternate.ss_size = sizeof(g_alt_stack);
        sigaltstack(&alternate, nullptr);
    }
    unsigned installed = 0;
    struct sigaction action{};
    sigemptyset(&action.sa_mask);
    action.sa_flags = SA_SIGINFO | SA_ONSTACK;
    action.sa_sigaction = SignalHandler;
    for (unsigned i = 0; i < sizeof(kSignals) / sizeof(kSignals[0]); ++i)
        if (sigaction(kSignals[i], &action, &g_previous[i]) == 0) ++installed;
    Note(installed == sizeof(kSignals) / sizeof(kSignals[0])
             ? "Native signal handlers installed."
             : "One or more native signal handlers could not be installed.");

}

bool NativeReady() { return g_ready.load(std::memory_order_acquire) != 0; }
const char *PrivateReportPath() { return NativeReady() ? g_path : ""; }
const char *PrivateDirectory() { return NativeReady() ? g_directory : ""; }

void SetDownloadFd(int owned_fd) {
    /* Set once, after the full existing header is copied and the row published. */
    int expected = -1;
    if (!g_download_fd.compare_exchange_strong(expected, owned_fd)) close(owned_fd);
}

void AddLog(const char *text, std::size_t length) {
    if (!text) return;
    if (length > kLineBytes) length = kLineBytes;
    const unsigned index = g_cursor.fetch_add(1, std::memory_order_acq_rel);
    Slot &slot = g_slots[index % kSlots];
    unsigned unlocked = 0;
    if (!slot.busy.compare_exchange_strong(unlocked, 1, std::memory_order_acquire)) return;
    for (unsigned j = 0; j < length; ++j)
        __atomic_store_n(&slot.bytes[j], static_cast<unsigned char>(text[j]), __ATOMIC_RELAXED);
    slot.length.store(static_cast<unsigned>(length), std::memory_order_relaxed);
    slot.sequence.store(index + 1, std::memory_order_release);
    slot.busy.store(0, std::memory_order_release);
}

void Note(const char *text) {
#ifdef __ANDROID__
    __android_log_print(ANDROID_LOG_INFO, "QuestCrashLogger", "%s", text);
#else
    (void)text;
#endif
}

void RefreshNativeModules() {
    if (g_refreshing.test_and_set(std::memory_order_acquire)) return;
    unsigned count = 0;
    dl_iterate_phdr(CacheModule, &count);
    g_module_count.store(count, std::memory_order_release);
    g_refreshing.clear(std::memory_order_release);
}

void SaveLogSnapshot(const char *text, std::size_t length) {
    if (!NativeReady() || !text || !length) return;
    char temporary[PATH_MAX + 32], target[PATH_MAX + 32];
    std::snprintf(temporary, sizeof(temporary), "%s.logcat.tmp", g_path);
    std::snprintf(target, sizeof(target), "%s.logcat", g_path);
    const int fd = open(temporary, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0600);
    if (fd < 0) return;
    const bool ok = WriteAll(fd, text, length);
    close(fd);
    if (ok) rename(temporary, target); else unlink(temporary);
}

void Flush() {
    const int local = g_private_fd.load(), downloads = g_download_fd.load();
    if (local >= 0) fsync(local);
    if (downloads >= 0) fsync(downloads);
}

bool CopyReport(const char *source, int destination) {
    const int input = open(source, O_RDONLY | O_CLOEXEC);
    if (input < 0) return false;
    char buffer[16384];
    bool ok = true;
    while (true) {
        const ssize_t n = read(input, buffer, sizeof(buffer));
        if (n < 0 && errno == EINTR) continue;
        if (n == 0) break;
        if (n < 0 || !WriteAll(destination, buffer, static_cast<std::size_t>(n))) {
            ok = false;
            break;
        }
    }
    close(input);
    return ok;
}
} // namespace qcl
