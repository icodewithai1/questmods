#include "crash_format.hpp"
#include <algorithm>
#include <cxxabi.h>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <utility>

namespace qcl {
namespace {
/* Field numbers follow AOSP debuggerd/proto/tombstone.proto. Unknown fields
 * are skipped; all lengths/varints are bounded by the supplied byte span. */
struct Field { unsigned number{}, wire{}; std::uint64_t value{}; std::string_view bytes; };
struct Reader {
    std::string_view input;
    bool valid{true};
    bool Varint(std::uint64_t &out) {
        out = 0;
        for (unsigned i = 0; i < 10; ++i) {
            if (input.empty()) return valid = false;
            const unsigned byte = static_cast<unsigned char>(input.front());
            input.remove_prefix(1);
            if (i == 9 && byte > 1) return valid = false;
            out |= static_cast<std::uint64_t>(byte & 127) << (i * 7);
            if (!(byte & 128)) return true;
        }
        return valid = false;
    }
    bool Next(Field &field) {
        if (input.empty() || !valid) return false;
        std::uint64_t key;
        if (!Varint(key) || !(key >> 3) || key >> 3 > 0x1fffffff) return valid = false;
        field = {};
        field.number = static_cast<unsigned>(key >> 3);
        field.wire = key & 7;
        if (field.wire == 0) return Varint(field.value);
        std::uint64_t length = field.wire == 1 ? 8 : field.wire == 5 ? 4 : 0;
        if (field.wire == 2) {
            if (!Varint(length)) return false;
        } else if (field.wire != 1 && field.wire != 5) return valid = false;
        if (length > input.size()) return valid = false;
        field.bytes = input.substr(0, static_cast<std::size_t>(length));
        input.remove_prefix(static_cast<std::size_t>(length));
        return true;
    }
};

std::string Text(std::string_view value, std::size_t limit = 4096) {
    std::string out;
    for (char c : value.substr(0, limit)) {
        const unsigned byte = static_cast<unsigned char>(c);
        if (byte >= 32 || c == '\n' || c == '\t') out.push_back(c);
    }
    return out;
}

bool ParseFrame(std::string_view data, NativeFrame &frame) {
    Reader reader{data}; Field f;
    while (reader.Next(f)) {
        if (f.number == 1 && f.wire == 0) frame.pc = f.value;
        else if (f.number == 4 && f.wire == 2) frame.function = Text(f.bytes);
        else if (f.number == 5 && f.wire == 0) frame.offset = f.value;
        else if (f.number == 6 && f.wire == 2) frame.file = Text(f.bytes);
        else if (f.number == 8 && f.wire == 2) frame.build_id = Text(f.bytes, 128);
    }
    return reader.valid;
}

struct Thread {
    int tid{};
    std::string name;
    std::vector<NativeFrame> frames;
};
bool ParseThread(std::string_view data, Thread &thread) {
    Reader reader{data}; Field f;
    while (reader.Next(f)) {
        if (f.number == 1 && f.wire == 0) thread.tid = static_cast<int>(f.value);
        else if (f.number == 2 && f.wire == 2) thread.name = Text(f.bytes, 256);
        else if (f.number == 4 && f.wire == 2 && thread.frames.size() < 32) {
            NativeFrame frame;
            if (!ParseFrame(f.bytes, frame)) return false;
            thread.frames.push_back(std::move(frame));
        }
    }
    return reader.valid;
}

std::string Basename(std::string_view file) {
    const auto slash = file.find_last_of('/');
    return std::string(slash == std::string_view::npos ? file : file.substr(slash + 1));
}
std::string Function(const std::string &name) {
    int status = 0;
    char *demangled = abi::__cxa_demangle(name.c_str(), nullptr, nullptr, &status);
    std::string result = status == 0 && demangled ? demangled : name;
    std::free(demangled);
    return result;
}

std::string Time(std::int64_t ms) {
    const std::time_t seconds = static_cast<std::time_t>(ms / 1000);
    tm utc{};
    gmtime_r(&seconds, &utc);
    char out[64];
    std::strftime(out, sizeof(out), "%Y-%m-%d %H:%M:%S UTC", &utc);
    return out;
}

std::string FirstException(std::string_view logs) {
    std::string selected;
    std::istringstream lines{std::string(logs)};
    std::string line;
    while (std::getline(lines, line)) {
        if (line.find("Caused by:") != std::string::npos ||
            line.find("Exception:") != std::string::npos ||
            line.find("Error:") != std::string::npos ||
            line.find("Abort message:") != std::string::npos ||
            line.find("Assertion") != std::string::npos)
            selected = line.substr(0, 1000);
    }
    return selected;
}
} // namespace

bool ParseTombstone(std::string_view protobuf, Tombstone &result) {
    if (protobuf.empty() || protobuf.size() > 8 * 1024 * 1024) return false;
    Tombstone parsed;
    std::vector<Thread> threads;
    Reader reader{protobuf}; Field f;
    while (reader.Next(f)) {
        if (f.number == 5 && f.wire == 0) parsed.pid = static_cast<int>(f.value);
        else if (f.number == 6 && f.wire == 0) parsed.tid = static_cast<int>(f.value);
        else if (f.number == 10 && f.wire == 2) {
            Reader signal{f.bytes}; Field s;
            while (signal.Next(s)) {
                if (s.number == 1 && s.wire == 0) parsed.signal = static_cast<int>(s.value);
                else if (s.number == 2 && s.wire == 2) parsed.signal_name = Text(s.bytes, 64);
                else if (s.number == 4 && s.wire == 2) parsed.signal_code = Text(s.bytes, 64);
                else if (s.number == 8 && s.wire == 0) parsed.has_fault_address = s.value != 0;
                else if (s.number == 9 && s.wire == 0) parsed.fault_address = s.value;
            }
            if (!signal.valid) return false;
        } else if (f.number == 14 && f.wire == 2) parsed.abort_message = Text(f.bytes);
        else if (f.number == 15 && f.wire == 2 && parsed.cause.empty()) {
            Reader cause{f.bytes}; Field c;
            while (cause.Next(c))
                if (c.number == 1 && c.wire == 2) parsed.cause = Text(c.bytes);
            if (!cause.valid) return false;
        } else if (f.number == 16 && f.wire == 2 && threads.size() < 1024) {
            Reader entry{f.bytes}; Field e;
            Thread thread;
            while (entry.Next(e)) {
                if (e.number == 1 && e.wire == 0) thread.tid = static_cast<int>(e.value);
                else if (e.number == 2 && e.wire == 2 && !ParseThread(e.bytes, thread)) return false;
            }
            if (!entry.valid) return false;
            threads.push_back(std::move(thread));
        } else if (f.number == 18 && f.wire == 2 && parsed.game_logs.size() < 32768) {
            Reader buffer{f.bytes}; Field b;
            while (buffer.Next(b)) {
                if (b.number != 2 || b.wire != 2 || parsed.game_logs.size() >= 32768) continue;
                Reader message{b.bytes}; Field m;
                std::string tag, text;
                int pid = 0;
                while (message.Next(m)) {
                    if (m.number == 2 && m.wire == 0) pid = static_cast<int>(m.value);
                    else if (m.number == 5 && m.wire == 2) tag = Text(m.bytes, 128);
                    else if (m.number == 6 && m.wire == 2) text = Text(m.bytes, 2048);
                }
                if (!message.valid) return false;
                if ((!pid || pid == parsed.pid) && tag != "QuestCrashLogger" && !text.empty())
                    parsed.game_logs += tag + ": " + text + "\n";
            }
            if (!buffer.valid) return false;
        }
    }
    if (!reader.valid || parsed.pid <= 0 || (!parsed.signal && threads.empty())) return false;
    for (auto &thread : threads) {
        if (thread.tid != parsed.tid) continue;
        parsed.thread_name = std::move(thread.name);
        parsed.frames = std::move(thread.frames);
        break;
    }
    result = std::move(parsed);
    return true;
}

bool IsCrashExit(int reason) {
    return reason == 2 || reason == 3 || reason == 4 || reason == 5 ||
           reason == 6 || reason == 7 || reason == 9 || reason == 14;
}
std::string ExitReason(int reason) {
    switch (reason) {
        case 2: return "Process terminated by a signal";
        case 3: return "Android stopped the game because memory was low";
        case 4: return "Uncaught Java exception";
        case 5: return "Native code crash";
        case 6: return "Game stopped responding (ANR)";
        case 7: return "Game initialization failed";
        case 9: return "Android stopped the game for excessive resource usage";
        case 14: return "Android terminated a frozen process";
        default: return "Android recorded an unexpected process exit";
    }
}

std::string CrashFilename(std::int64_t timestamp_ms, int pid) {
    const std::time_t seconds = static_cast<std::time_t>(timestamp_ms / 1000);
    tm utc{}; gmtime_r(&seconds, &utc);
    char date[48], output[96];
    std::strftime(date, sizeof(date), "%Y%m%d-%H%M%S", &utc);
    std::snprintf(output, sizeof(output), "crash-%s-%d.txt", date, pid);
    return output;
}

std::string ReadSmallFile(const std::string &path, std::size_t maximum) {
    std::ifstream file(path, std::ios::binary);
    if (!file) return {};
    std::string contents(maximum, '\0');
    file.read(contents.data(), static_cast<std::streamsize>(maximum));
    contents.resize(static_cast<std::size_t>(file.gcount()));
    return contents;
}

std::string CleanGameLogs(std::string_view text, unsigned maximum_lines) {
    std::vector<std::string> lines;
    std::istringstream input{std::string(text.substr(0, 512 * 1024))};
    std::string line;
    while (std::getline(input, line)) {
        if (line.empty() || line.starts_with("---------") || line.starts_with("logcat:") ||
            line.find("QuestCrashLogger") != std::string::npos ||
            line.find("MEDIASTORE_READY") != std::string::npos) continue;
        line = Text(line, 4096);
        if (!lines.empty() && lines.back() == line) continue;
        lines.push_back(std::move(line));
    }
    std::string out;
    const std::size_t start = lines.size() > maximum_lines ? lines.size() - maximum_lines : 0;
    for (std::size_t i = start; i < lines.size(); ++i) out += lines[i] + "\n";
    if (out.size() > 64 * 1024) {
        const auto cut = out.find('\n', out.size() - 64 * 1024);
        out.erase(0, cut == std::string::npos ? out.size() : cut + 1);
    }
    return out;
}

std::string FormatNativeReport(std::string_view raw, std::string_view saved_logs) {
    constexpr std::string_view marker = "=== QCL_NATIVE_CRASH ===\n";
    const auto begin = raw.find(marker);
    if (begin == std::string_view::npos) return {};
    raw.remove_prefix(begin + marker.size());
    const auto end = raw.find("=== END QCL_NATIVE_CRASH ===");
    if (end != std::string_view::npos) raw = raw.substr(0, end);
    std::string out;
    if (raw.starts_with("Game crash\n")) {
        const auto logs = raw.find("\nGame logs:\n");
        out = std::string(raw.substr(0, logs));
        std::string combined(saved_logs);
        if (logs != std::string_view::npos) combined += "\n" + std::string(raw.substr(logs + 12));
        const std::string clean = CleanGameLogs(combined);
        if (!clean.empty()) out += "\nGame logs:\n" + clean;
    } else {
        /* Upgrade old register/map dumps without publishing their boilerplate. */
        out = "Game crash\n";
        std::istringstream lines{std::string(raw)};
        std::string line;
        while (std::getline(lines, line)) {
            if (line.starts_with("signal=")) out += "Signal: " + line.substr(7) + "\n";
            else if (line.starts_with("fault_address=")) out += "Fault address: " + line.substr(14) + "\n";
            else if (line.starts_with("pc=")) out += "Location: " + line.substr(3) + "\n";
            else if (line.starts_with("lr=")) out += "Caller: " + line.substr(3) + "\n";
        }
        std::string logs(saved_logs);
        constexpr std::string_view old_logs = "--- Last captured Unity / own-process logcat messages ---\n";
        const auto start_logs = raw.find(old_logs);
        if (start_logs != std::string_view::npos) {
            auto tail = raw.substr(start_logs + old_logs.size());
            const auto maps = tail.find("--- /proc/self/maps");
            logs += "\n" + std::string(tail.substr(0, maps));
        }
        const auto clean = CleanGameLogs(logs);
        if (!clean.empty()) out += "\nGame logs:\n" + clean;
    }
    return out;
}

std::string FormatAndroidExit(const AndroidExit &exit, std::string_view game_logs,
                              std::string_view native_report) {
    Tombstone tombstone;
    const bool native = ParseTombstone(exit.trace, tombstone);
    std::string logs(game_logs);
    if (native) logs += "\n" + tombstone.game_logs;
    const std::string clean_logs = CleanGameLogs(logs);
    std::ostringstream out;
    out << "Game crash\nTime: " << Time(exit.timestamp_ms) << "\n";
    if (!exit.process.empty()) out << "Process: " << exit.process << "\n";
    out << "PID: " << exit.pid << "\nReason: " << ExitReason(exit.reason) << "\n";
    std::string cause = native && !tombstone.cause.empty() ? tombstone.cause :
                        native && !tombstone.abort_message.empty() ? tombstone.abort_message : "";
    if (!cause.empty()) out << "Details: " << cause << "\n";
    else if (!exit.description.empty()) out << "Details: " << Text(exit.description) << "\n";
    if (!native && !native_report.empty()) {
        std::istringstream captured{std::string(native_report)};
        std::string line;
        while (std::getline(captured, line)) {
            if (line.starts_with("Crash: ")) out << "Signal: " << line.substr(7) << "\n";
            else if (line.starts_with("Reason: ")) out << "Native reason: " << line.substr(8) << "\n";
            else if (line.starts_with("Fault address")) out << line << "\n";
        }
    }
    const auto last_error = FirstException(clean_logs);
    if (!last_error.empty()) out << "Last reported error: " << last_error << "\n";
    if (!native && exit.status) out << "Exit status: " << exit.status << "\n";
    if (native) {
        out << "Signal: " << (tombstone.signal_name.empty() ? std::to_string(tombstone.signal) : tombstone.signal_name);
        if (!tombstone.signal_code.empty()) out << " (" << tombstone.signal_code << ")";
        out << "\n";
        if (tombstone.has_fault_address) out << "Fault address: 0x" << std::hex << tombstone.fault_address << std::dec << "\n";
        if (!tombstone.thread_name.empty()) out << "Thread: " << tombstone.thread_name << "\n";
        if (!tombstone.frames.empty()) {
            out << "\nNative stack:\n";
            unsigned index = 0;
            for (const auto &frame : tombstone.frames) {
                out << "  #" << std::setw(2) << std::setfill('0') << index++ << " pc 0x"
                    << std::hex << frame.pc << std::dec << " " << Basename(frame.file);
                if (!frame.function.empty()) out << " (" << Function(frame.function) << "+0x" << std::hex << frame.offset << std::dec << ")";
                out << "\n";
            }
        }
    }
    if ((!native || tombstone.frames.empty()) && !native_report.empty()) {
        const auto start = native_report.find("Native stack:\n");
        if (start != std::string_view::npos) {
            auto stack = native_report.substr(start);
            out << "\n" << stack.substr(0, stack.find("\nGame logs:")) << "\n";
        }
    }
    if (!native && !exit.trace.empty()) {
        const bool text_trace = exit.trace.find("----- pid ") < 256 ||
                                exit.trace.find("*** ***") < 256 ||
                                exit.trace.find("DALVIK THREADS") < 512;
        if (text_trace) {
            std::istringstream input(exit.trace);
            std::string line, summary;
            unsigned count = 0;
            bool main_thread = false;
            while (count < 50 && std::getline(input, line)) {
                if (line.starts_with("\"main\"")) main_thread = true;
                else if (main_thread && line.starts_with("\"")) break;
                const auto first = line.find_first_not_of(" \t");
                const auto body = first == std::string::npos ? std::string{} : line.substr(first);
                if (body.starts_with("#") || body.starts_with("Abort message:") ||
                    body.starts_with("Cause:") || body.starts_with("signal ") ||
                    (main_thread && (body.starts_with("at ") || body.starts_with("native:") ||
                                     body.find("waiting to lock") != std::string::npos))) {
                    summary += Text(line, 1000) + "\n";
                    ++count;
                }
            }
            if (!summary.empty()) out << "\nAndroid stack:\n" << summary;
        }
    }
    if (!clean_logs.empty()) out << "\nGame logs:\n" << clean_logs;
    return out.str();
}
} // namespace qcl
