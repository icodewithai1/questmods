#include "android_support.hpp"
#include "native_report.hpp"

#include <BNM/BasicMonoStructures.hpp>
#include <BNM/MethodBase.hpp>
#include <dobby.h>
#include <cstdio>
#include <cstring>
#include <dlfcn.h>
#include <time.h>
#include <pthread.h>

namespace qcl {
namespace {
using String = BNM::Structures::Mono::String;
using MethodInfo = BNM::IL2CPP::MethodInfo;
using LogCallback = void (*)(String *, String *, int, bool, const MethodInfo *);
LogCallback g_original{};
bool g_installed{};
pthread_mutex_t g_hook_lock = PTHREAD_MUTEX_INITIALIZER;
struct HookLock {
    HookLock() { pthread_mutex_lock(&g_hook_lock); }
    ~HookLock() { pthread_mutex_unlock(&g_hook_lock); }
};

/* Bounded UTF-16 conversion using BNM's Mono string representation. No heap
 * allocation, no JNI, and no calls to Unity from the logging callback. */
std::size_t AppendString(char *out, std::size_t capacity, const String *value) {
    if (!value || value->length <= 0 || !capacity) return 0;
    std::size_t written = 0;
    const int count = value->length < 32768 ? value->length : 32768;
    for (int i = 0; i < count; ++i) {
        unsigned code = value->chars[i];
        if (code >= 0xd800 && code <= 0xdbff) {
            if (i + 1 < count && value->chars[i + 1] >= 0xdc00 && value->chars[i + 1] <= 0xdfff)
                code = 0x10000 + ((code - 0xd800) << 10) + (value->chars[++i] - 0xdc00);
            else code = 0xfffd;
        } else if (code >= 0xdc00 && code <= 0xdfff) code = 0xfffd;
        unsigned bytes = code < 0x80 ? 1 : code < 0x800 ? 2 : code < 0x10000 ? 3 : 4;
        if (written + bytes > capacity) break;
        if (bytes == 1) out[written++] = static_cast<char>(code);
        else {
            out[written++] = static_cast<char>((bytes == 2 ? 0xc0 : bytes == 3 ? 0xe0 : 0xf0) |
                                              (code >> (6 * (bytes - 1))));
            for (unsigned b = bytes - 1; b; --b)
                out[written++] = static_cast<char>(0x80 | ((code >> (6 * (b - 1))) & 0x3f));
        }
    }
    return written;
}

void OnUnityLog(String *message, String *stack, int type, bool on_main_thread, const MethodInfo *method) {
    char line[4096];
    timespec now{};
    clock_gettime(CLOCK_REALTIME, &now);
    int prefix = std::snprintf(line, sizeof(line), "[Unity type=%d unix=%lld.%03ld] ",
                               type, static_cast<long long>(now.tv_sec), now.tv_nsec / 1000000);
    std::size_t length = static_cast<std::size_t>(prefix);
    const std::size_t message_limit = stack && stack->length > 0 ? 1800 : sizeof(line) - length;
    length += AppendString(line + length, message_limit, message);
    if (stack && stack->length > 0 && length + 1 < sizeof(line)) {
        line[length++] = '\n';
        length += AppendString(line + length, sizeof(line) - length, stack);
    }
    AddLog(line, length);
    const LogCallback original = __atomic_load_n(&g_original, __ATOMIC_ACQUIRE);
    if (original) original(message, stack, type, on_main_thread, method);
}
} // namespace

bool EnableUnityCapture(unsigned unity_header_version) {
    if (unity_header_version != UNITY_VER) {
        SetLastError("The requested Unity header selector does not match this build; rebuild for the game's Unity version.");
        return false;
    }
    HookLock lock;
    if (g_installed) return true;
    void *handle = dlopen("libil2cpp.so", RTLD_NOW | RTLD_NOLOAD);
    if (!handle) {
        SetLastError("The game's IL2CPP library is not loaded yet.");
        return false;
    }
    const auto domain_get = reinterpret_cast<void *(*)()>(dlsym(handle, "il2cpp_domain_get"));
    const auto thread_current = reinterpret_cast<void *(*)()>(dlsym(handle, "il2cpp_thread_current"));
    const auto assemblies_get = reinterpret_cast<const void **(*)(void *, std::size_t *)>(
        dlsym(handle, "il2cpp_domain_get_assemblies"));
    const auto image_get = reinterpret_cast<const void *(*)(const void *)>(
        dlsym(handle, "il2cpp_assembly_get_image"));
    const auto class_get = reinterpret_cast<void *(*)(const void *, const char *, const char *)>(
        dlsym(handle, "il2cpp_class_from_name"));
    const auto method_get = reinterpret_cast<const MethodInfo *(*)(void *, const char *, int)>(
        dlsym(handle, "il2cpp_class_get_method_from_name"));
    const auto name_get = reinterpret_cast<const char *(*)(const MethodInfo *)>(
        dlsym(handle, "il2cpp_method_get_name"));
    const auto count_get = reinterpret_cast<unsigned (*)(const MethodInfo *)>(
        dlsym(handle, "il2cpp_method_get_param_count"));
    const auto flags_get = reinterpret_cast<unsigned (*)(const MethodInfo *, unsigned *)>(
        dlsym(handle, "il2cpp_method_get_flags"));
    bool success = false;
    do {
        if (!domain_get || !thread_current || !assemblies_get || !image_get || !class_get ||
            !method_get || !name_get || !count_get || !flags_get) {
            SetLastError("Optional Unity capture requires IL2CPP exports missing from this game.");
            break;
        }
        /* Do not attach arbitrary worker threads to IL2CPP or poll its startup.
         * The loader must call on an existing game thread after VM startup. */
        if (!thread_current()) {
            SetLastError("EnableUnityCapture must run on an existing IL2CPP game thread after initialization.");
            break;
        }
        void *domain = domain_get();
        std::size_t count = 0;
        const void **assemblies = domain ? assemblies_get(domain, &count) : nullptr;
        if (!assemblies || !count) {
            SetLastError("IL2CPP assemblies are not initialized yet.");
            break;
        }
        const MethodInfo *info = nullptr;
        for (std::size_t i = 0; i < count && !info; ++i) {
            const void *image = image_get(assemblies[i]);
            void *klass = image ? class_get(image, "UnityEngine", "Application") : nullptr;
            if (klass) info = method_get(klass, "CallLogCallback", 4);
        }
        if (!info) {
            SetLastError("Optional Unity capture could not find Application.CallLogCallback.");
            break;
        }
        unsigned implementation_flags = 0;
        const unsigned flags = flags_get(info, &implementation_flags);
        if (info->name != name_get(info) || info->parameters_count != count_get(info) ||
            info->flags != (flags & 0xffff) || !(flags & 0x10)) {
            SetLastError("The game's MethodInfo layout does not match this BNM build.");
            break;
        }
        BNM::MethodBase method(info);
        void *target = reinterpret_cast<void *>(method.GetOffset());
        if (!target || DobbyHook(target, reinterpret_cast<void *>(OnUnityLog),
                                reinterpret_cast<void **>(&g_original)) != 0 ||
            !__atomic_load_n(&g_original, __ATOMIC_ACQUIRE)) {
            SetLastError("DobbyHook failed while enabling optional Unity capture.");
            break;
        }
        g_installed = true;
        success = true;
        Note("Optional Unity capture explicitly enabled with BNM MethodBase + DobbyHook.");
        SetLastError("");
    } while (false);
    if (!success) dlclose(handle);
    return success;
}
} // namespace qcl
