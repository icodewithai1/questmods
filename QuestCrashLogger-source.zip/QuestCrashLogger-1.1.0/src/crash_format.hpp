#pragma once
#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace qcl {
struct NativeFrame {
    std::uint64_t pc{}, offset{};
    std::string file, function, build_id;
};
struct AndroidExit {
    int reason{}, status{}, pid{};
    std::int64_t timestamp_ms{};
    std::string process, description, trace;
};
struct Tombstone {
    int pid{}, tid{}, signal{};
    std::uint64_t fault_address{};
    bool has_fault_address{};
    std::string signal_name, signal_code, abort_message, cause, thread_name;
    std::vector<NativeFrame> frames;
    std::string game_logs;
};
bool ParseTombstone(std::string_view protobuf, Tombstone &result);
bool IsCrashExit(int reason);
std::string ExitReason(int reason);
std::string CrashFilename(std::int64_t timestamp_ms, int pid);
std::string ReadSmallFile(const std::string &path, std::size_t maximum = 1024 * 1024);
std::string CleanGameLogs(std::string_view text, unsigned maximum_lines = 100);
std::string FormatNativeReport(std::string_view raw, std::string_view saved_logs);
std::string FormatAndroidExit(const AndroidExit &exit, std::string_view game_logs,
                              std::string_view native_report = {});
}
