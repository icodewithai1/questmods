#pragma once
#include "crash_format.hpp"
#include <jni.h>
#include <vector>

namespace qcl {
std::vector<AndroidExit> ReadAndroidExitHistory(JNIEnv *env, jobject context, const char *package_name);
}
