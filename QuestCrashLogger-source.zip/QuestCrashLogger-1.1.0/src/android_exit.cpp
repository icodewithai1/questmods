#include "android_exit.hpp"
#include <android/api-level.h>
#include <algorithm>

namespace qcl {
namespace {
bool Ok(JNIEnv *env, bool valid = true) {
    if (env->ExceptionCheck()) { env->ExceptionClear(); return false; }
    return valid;
}
struct Frame {
    JNIEnv *env;
    bool active;
    explicit Frame(JNIEnv *e) : env(e), active(e->PushLocalFrame(80) == JNI_OK) {
        if (!active) Ok(env, false);
    }
    ~Frame() {
        if (active) {
            if (env->ExceptionCheck()) env->ExceptionClear();
            env->PopLocalFrame(nullptr);
        }
    }
};
std::string Utf8(JNIEnv *env, jstring string) {
    if (!string) return {};
    const char *data = env->GetStringUTFChars(string, nullptr);
    if (!Ok(env, data != nullptr)) return {};
    std::string out(data);
    env->ReleaseStringUTFChars(string, data);
    return out;
}
std::string ReadTrace(JNIEnv *env, jobject stream, std::size_t maximum) {
    if (!stream) return {};
    jclass cls = env->FindClass("java/io/InputStream");
    if (!Ok(env, cls != nullptr)) return {};
    jmethodID read = env->GetMethodID(cls, "read", "([B)I");
    if (!Ok(env, read != nullptr)) return {};
    jmethodID close = env->GetMethodID(cls, "close", "()V");
    if (!Ok(env, close != nullptr)) return {};
    jbyteArray array = env->NewByteArray(8192);
    if (!Ok(env, array != nullptr)) return {};
    std::string trace;
    jbyte buffer[8192];
    unsigned empty_reads = 0;
    while (trace.size() < maximum && empty_reads < 8) {
        jvalue argument{}; argument.l = array;
        const jint count = env->CallIntMethodA(stream, read, &argument);
        if (!Ok(env) || count < 0 || count > static_cast<jint>(sizeof(buffer))) break;
        if (!count) { ++empty_reads; continue; }
        env->GetByteArrayRegion(array, 0, count, buffer);
        if (!Ok(env)) break;
        const auto keep = std::min(static_cast<std::size_t>(count), maximum - trace.size());
        trace.append(reinterpret_cast<const char *>(buffer), keep);
    }
    env->CallVoidMethod(stream, close);
    Ok(env);
    env->DeleteLocalRef(array); env->DeleteLocalRef(cls);
    return trace;
}
} // namespace

std::vector<AndroidExit> ReadAndroidExitHistory(JNIEnv *env, jobject context, const char *package_name) {
    std::vector<AndroidExit> exits;
    if (android_get_device_api_level() < 30) return exits;
    Frame frame(env);
    if (!frame.active) return exits;
    jclass ctx = env->FindClass("android/content/Context");
    if (!Ok(env, ctx != nullptr)) return exits;
    jmethodID service = env->GetMethodID(ctx, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
    if (!Ok(env, service != nullptr)) return exits;
    jstring name = env->NewStringUTF("activity");
    if (!Ok(env, name != nullptr)) return exits;
    jvalue service_arg{}; service_arg.l = name;
    jobject manager = env->CallObjectMethodA(context, service, &service_arg);
    if (!Ok(env, manager != nullptr)) return exits;
    jclass am = env->FindClass("android/app/ActivityManager");
    if (!Ok(env, am != nullptr)) return exits;
    jmethodID history = env->GetMethodID(am, "getHistoricalProcessExitReasons", "(Ljava/lang/String;II)Ljava/util/List;");
    if (!Ok(env, history != nullptr)) return exits;
    jstring package = env->NewStringUTF(package_name);
    if (!Ok(env, package != nullptr)) return exits;
    jvalue history_args[3]{};
    history_args[0].l = package; history_args[2].i = 12;
    jobject list = env->CallObjectMethodA(manager, history, history_args);
    if (!Ok(env, list != nullptr)) return exits;
    jclass lists = env->FindClass("java/util/List");
    if (!Ok(env, lists != nullptr)) return exits;
    jmethodID size = env->GetMethodID(lists, "size", "()I");
    if (!Ok(env, size != nullptr)) return exits;
    jmethodID get = env->GetMethodID(lists, "get", "(I)Ljava/lang/Object;");
    if (!Ok(env, get != nullptr)) return exits;
    jclass info = env->FindClass("android/app/ApplicationExitInfo");
    if (!Ok(env, info != nullptr)) return exits;
    jmethodID reason = env->GetMethodID(info, "getReason", "()I");
    if (!Ok(env, reason != nullptr)) return exits;
    jmethodID status = env->GetMethodID(info, "getStatus", "()I");
    if (!Ok(env, status != nullptr)) return exits;
    jmethodID pid = env->GetMethodID(info, "getPid", "()I");
    if (!Ok(env, pid != nullptr)) return exits;
    jmethodID timestamp = env->GetMethodID(info, "getTimestamp", "()J");
    if (!Ok(env, timestamp != nullptr)) return exits;
    jmethodID process = env->GetMethodID(info, "getProcessName", "()Ljava/lang/String;");
    if (!Ok(env, process != nullptr)) return exits;
    jmethodID description = env->GetMethodID(info, "getDescription", "()Ljava/lang/String;");
    if (!Ok(env, description != nullptr)) return exits;
    jmethodID trace = env->GetMethodID(info, "getTraceInputStream", "()Ljava/io/InputStream;");
    if (!Ok(env, trace != nullptr)) return exits;
    const jint count = env->CallIntMethod(list, size);
    if (!Ok(env)) return exits;
    std::size_t trace_budget = 16 * 1024 * 1024;
    for (jint i = 0; i < std::min(count, 12); ++i) {
        jvalue index{}; index.i = i;
        jobject object = env->CallObjectMethodA(list, get, &index);
        if (!Ok(env, object != nullptr)) continue;
        AndroidExit exit;
        exit.reason = env->CallIntMethod(object, reason);
        if (!Ok(env)) { env->DeleteLocalRef(object); continue; }
        exit.status = env->CallIntMethod(object, status);
        if (!Ok(env)) { env->DeleteLocalRef(object); continue; }
        exit.pid = env->CallIntMethod(object, pid);
        if (!Ok(env)) { env->DeleteLocalRef(object); continue; }
        exit.timestamp_ms = env->CallLongMethod(object, timestamp);
        if (!Ok(env)) { env->DeleteLocalRef(object); continue; }
        auto p = static_cast<jstring>(env->CallObjectMethod(object, process));
        if (Ok(env)) exit.process = Utf8(env, p);
        auto d = static_cast<jstring>(env->CallObjectMethod(object, description));
        if (Ok(env)) exit.description = Utf8(env, d);
        if (IsCrashExit(exit.reason) && trace_budget) {
            jobject input = env->CallObjectMethod(object, trace);
            if (Ok(env) && input) {
                exit.trace = ReadTrace(env, input, std::min<std::size_t>(8 * 1024 * 1024, trace_budget));
                trace_budget -= exit.trace.size();
                env->DeleteLocalRef(input);
            }
        }
        if (p) env->DeleteLocalRef(p);
        if (d) env->DeleteLocalRef(d);
        env->DeleteLocalRef(object);
        if (exit.pid > 0 && exit.timestamp_ms > 0) exits.push_back(std::move(exit));
    }
    return exits;
}
} // namespace qcl
