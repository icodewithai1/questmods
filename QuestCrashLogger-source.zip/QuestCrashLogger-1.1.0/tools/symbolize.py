#!/usr/bin/env python3
"""Add file:line locations using matching game ELF debug symbols."""
import argparse
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('report', type=Path)
parser.add_argument('symbols', type=Path, help='Directory containing matching game .so/.sym.so/.debug files')
args = parser.parse_args()
tool = shutil.which('llvm-addr2line')
if not tool:
    ndk = os.environ.get('ANDROID_NDK_HOME') or os.environ.get('ANDROID_NDK_ROOT')
    if ndk:
        candidates = list(Path(ndk).glob('toolchains/llvm/prebuilt/*/bin/llvm-addr2line*'))
        if candidates:
            tool = str(candidates[0])
if not tool:
    parser.error('Set ANDROID_NDK_HOME or put llvm-addr2line on PATH.')
text = args.report.read_text(errors='replace')
files = [p for p in args.symbols.rglob('*') if p.is_file()]
resolved = []
for match in re.finditer(r'^\s*(#\d+)\s+pc\s+(0x[0-9a-fA-F]+)\s+(\S+)', text, re.MULTILINE):
    frame, address, name = match.groups()
    name = Path(name).name
    stem = name[:-3] if name.endswith('.so') else name
    variants = (stem + '.sym.so', name + '.debug', name + '.sym', name)
    symbol = next((p for variant in variants for p in files if p.name == variant), None)
    if not symbol:
        continue
    run = subprocess.run([tool, '-C', '-f', '-i', '-e', str(symbol), address], text=True, capture_output=True)
    if run.returncode:
        continue
    lines = run.stdout.splitlines()
    for index in range(0, len(lines) - 1, 2):
        function, location = lines[index:index + 2]
        if '??' not in location and re.search(r':[1-9][0-9]*(?:\D|$)', location):
            resolved.append(f'{frame} {function} at {location}')
sys.stdout.write(text)
if resolved:
    sys.stdout.write('\nResolved source locations:\n' + '\n'.join(resolved) + '\n')
else:
    print('No source lines resolved. The matching game symbols must include line information.', file=sys.stderr)
