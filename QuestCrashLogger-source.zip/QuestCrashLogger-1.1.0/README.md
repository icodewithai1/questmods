# QuestCrashLogger 1.1.0

Native ARM64 crash logging for Android / Meta Quest.

Reports go to `Download/QuestCrashLogs/<package>/` using MediaStore.

- `test.txt` is exported once. Clearing the app's data resets this first-launch marker.
- `crash-<date>-<pid>.txt` contains an actual captured crash or Android-recorded failure.
- **Reopen the game after a crash to export the report.** Android's final crash record is available after the old process has exited.

Reports include the exit reason, available native stack/functions, and recent game logs.
Java/C# file names and line numbers are included when present in the game's logs or Android trace.
Native source lines require the game's matching debug symbols; stripped releases may only provide a library and offset.

The logger saves game-log snapshots privately during play. It recovers its native
signal reports and, on Android 11+, Android's saved exit records. Signal capture is armed
after initial game startup. Android 12+ may
also provide a native tombstone with the crashing thread's full native backtrace.
Normal launches do not create more public test/session files.

## Load

Replace the previous library with `libquestcrashlogger.so`; load only one version.
Use the same loader initialization as before:

```cpp
QuestCrashLogger_Initialize(env, context);
```

`env` must belong to the calling thread; `context` must be an Android Context.
Java `System.loadLibrary("questcrashlogger")` also tries initialization through `JNI_OnLoad`.
The C API is in `include/QuestCrashLogger.h`. BNM/Dobby Unity hooking remains optional.

## Build

Requires a Linux host, Android NDK r27+, CMake 3.22–3.31, and Ninja.

```bash
export ANDROID_NDK_HOME=/path/to/android-ndk-r30
bash build.sh
```

Output: `dist/arm64-v8a/libquestcrashlogger.so`.
BNM and Dobby sources are included; exact versions are in `dependencies.lock.json`.

To add source locations when matching game symbols are available:

```bash
python3 tools/symbolize.py crash-report.txt /path/to/game-symbols > crash-symbolized.txt
```

No logger can reconstruct missing game source/debug information. Android's exit/trace
availability varies by OS; a kill or power loss may leave only an exit reason and saved logs.
