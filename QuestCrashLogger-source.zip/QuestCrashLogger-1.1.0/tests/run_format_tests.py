#!/usr/bin/env python3
import os
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix="qcl-format-tests-") as temp:
    executable = Path(temp) / "format-tests"
    subprocess.run([
        os.environ.get("CXX", "g++"), "-std=c++20", "-O2", "-Wall", "-Wextra",
        "-I", str(root / "src"), str(root / "src/crash_format.cpp"),
        str(root / "tests/crash_format_harness.cpp"), "-o", str(executable),
    ], check=True)
    subprocess.run([str(executable)], check=True, timeout=15)
