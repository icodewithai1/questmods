#!/usr/bin/env python3
"""Exercise the same signal/file/ring code on a Linux host, in child processes."""
import json
import os
from pathlib import Path
import signal
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
results = []
with tempfile.TemporaryDirectory(prefix="qcl-native-tests-") as temp:
    temp = Path(temp)
    harness = temp / "harness"
    subprocess.run([
        os.environ.get("CXX", "g++"), "-std=c++20", "-O2", "-pthread", "-Wall", "-Wextra",
        "-I", str(root / "src"), str(root / "src/native_report.cpp"),
        str(root / "tests/native_harness.cpp"), "-o", str(harness),
    ], check=True)
    for mode in ["healthy", "abort", "segv", "bus", "ill", "fpe", "trap",
                 "chain", "chain-segv", "stress", "kill", "private-only",
                 "ignored-trap", "ignored-abort", "deferred-chain"]:
        private = temp / mode
        private.mkdir()
        shared = temp / (mode + "-downloads.txt")
        command = [str(harness), str(private), mode]
        if mode != "private-only":
            command.append(str(shared))
        run = subprocess.run(command, capture_output=True, timeout=10)
        report = next(private.glob("QuestCrash-*.txt"))
        content = report.read_text(errors="replace")
        expected = {"healthy": 0, "chain": 73, "deferred-chain": 73, "segv": -signal.SIGSEGV,
                    "ignored-trap": 0, "ignored-abort": 0,
                    "chain-segv": 74, "kill": -signal.SIGKILL,
                    "bus": -signal.SIGBUS, "ill": -signal.SIGILL,
                    "fpe": -signal.SIGFPE, "trap": -signal.SIGTRAP}.get(mode, -signal.SIGABRT)
        assert run.returncode == expected, (mode, run.returncode, expected, run.stderr)
        crashed = mode not in ("healthy", "kill", "ignored-trap", "ignored-abort")
        assert ("=== QCL_NATIVE_CRASH ===" in content) == crashed, mode
        if crashed:
            assert "=== END QCL_NATIVE_CRASH ===" in content, mode
            assert "pc 0x" in content and "Native stack:" in content and "Reason:" in content, mode
            assert "/proc/self/maps" not in content and "BNM:" not in content, mode
            if mode != "stress":
                assert "native-test-sentinel" in content, mode
            if mode != "private-only":
                assert shared.read_bytes() == report.read_bytes(), mode
                assert Path(str(report) + ".delivered").read_text() == "1", mode
            else:
                assert Path(str(report) + ".delivered").read_text() == "", mode
        if mode in ("chain", "deferred-chain"):
            assert (private / "chain.txt").read_text() == "previous-handler-ran\n"
        results.append({"case": mode, "result": "passed", "exit": run.returncode})
print(json.dumps({"platform": "Linux x86_64 host; Android device not exercised", "tests": results}, indent=2))
