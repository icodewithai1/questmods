#include "crash_format.hpp"
#include <cassert>
#include <cstdio>

std::string Varint(std::uint64_t value) {
    std::string out;
    do {
        unsigned byte = value & 127;
        value >>= 7;
        out.push_back(static_cast<char>(byte | (value ? 128 : 0)));
    } while (value);
    return out;
}
std::string Number(unsigned field, std::uint64_t value) {
    return Varint(static_cast<std::uint64_t>(field) << 3) + Varint(value);
}
std::string Bytes(unsigned field, const std::string &data) {
    return Varint((static_cast<std::uint64_t>(field) << 3) | 2) + Varint(data.size()) + data;
}
int main() {
    const auto frame = Number(1, 0x1234) + Bytes(4, "_ZN6Player6UpdateEv") +
        Number(5, 8) + Bytes(6, "/data/app/game/lib/arm64/libil2cpp.so");
    const auto other = Number(1, 18) + Bytes(2, "other thread") + Bytes(4, Number(1, 0x9999));
    const auto crashing = Number(1, 19) + Bytes(2, "UnityMain") + Bytes(4, frame);
    const auto signal = Number(1, 11) + Bytes(2, "SIGSEGV") + Bytes(4, "SEGV_MAPERR") + Number(8, 1);
    const auto log = Number(2, 42) + Bytes(5, "Unity") +
        Bytes(6, "NullReferenceException: missing player\nat Player.Update (at Player.cs:37)");
    const auto tombstone = Number(5, 42) + Number(6, 19) + Bytes(10, signal) +
        Bytes(15, Bytes(1, "null pointer dereference")) +
        Bytes(16, Number(1, 18) + Bytes(2, other)) +
        Bytes(16, Number(1, 19) + Bytes(2, crashing)) + Bytes(18, Bytes(2, log));
    qcl::Tombstone parsed;
    assert(qcl::ParseTombstone(tombstone, parsed));
    assert(parsed.pid == 42 && parsed.tid == 19 && parsed.signal == 11);
    assert(parsed.has_fault_address && parsed.fault_address == 0);
    assert(parsed.frames.size() == 1 && parsed.frames[0].pc == 0x1234);
    assert(parsed.thread_name == "UnityMain" && parsed.cause == "null pointer dereference");
    assert(qcl::ParseTombstone(tombstone + Bytes(99, "future field"), parsed));
    assert(!qcl::ParseTombstone(Bytes(10, std::string("\x80", 1)), parsed));
    assert(!qcl::ParseTombstone(std::string(11, '\x80'), parsed));
    assert(!qcl::ParseTombstone("\x52\xff\xff\xff\xff\x7f", parsed));
    assert(!qcl::ParseTombstone(std::string(8 * 1024 * 1024 + 1, 'x'), parsed));
    assert(qcl::ParseTombstone(tombstone + Bytes(100, std::string(700 * 1024, 'x')), parsed));
    assert(!qcl::ParseTombstone(tombstone.substr(0, tombstone.size() - 1), parsed));
    for (std::size_t i = 0; i < tombstone.size(); ++i)
        qcl::ParseTombstone(std::string_view(tombstone).substr(0, i), parsed);

    qcl::AndroidExit exit{5, 11, 42, 1700000000000LL, "test.game", "native crash", tombstone};
    const auto report = qcl::FormatAndroidExit(exit, "QuestCrashLogger: internal setup\nGame: last event\n");
    assert(report.find("null pointer dereference") != std::string::npos);
    assert(report.find("Fault address: 0x0") != std::string::npos);
    assert(report.find("#00 pc 0x1234 libil2cpp.so (Player::Update()+0x8)") != std::string::npos);
    assert(report.find("Player.cs:37") != std::string::npos);
    assert(report.find("other thread") == std::string::npos);
    assert(report.find("QuestCrashLogger: internal") == std::string::npos);
    assert(report.find("BNM:") == std::string::npos);

    const std::string raw = "QCL private session\n=== QCL_NATIVE_CRASH ===\n"
        "Game crash\nCrash: SIGSEGV\nReason: Invalid memory access\n\n"
        "Native stack:\n  #00 pc 0x123 libgame.so\n\nGame logs:\nGame: crash event\n"
        "=== END QCL_NATIVE_CRASH ===\n";
    const auto native = qcl::FormatNativeReport(raw, "Game: earlier event\n");
    assert(native.starts_with("Game crash\n") && native.find("libgame.so") != std::string::npos);
    assert(native.find("earlier event") != std::string::npos && native.find("crash event") != std::string::npos);
    assert(native.find("QCL_NATIVE_CRASH") == std::string::npos);
    qcl::AndroidExit no_trace{5, 11, 42, 1700000000000LL, "test.game", "native crash", ""};
    const auto native_fallback = qcl::FormatAndroidExit(no_trace, "", native);
    assert(native_fallback.find("Native reason: Invalid memory access") != std::string::npos);
    assert(native_fallback.find("Signal: SIGSEGV") != std::string::npos);

    const auto legacy = qcl::FormatNativeReport("BNM: old header\n=== QCL_NATIVE_CRASH ===\n"
        "signal=11\npc=0x123\nlr=0x456\nx0=0xffff\n--- /proc/self/maps ---\nraw memory map\n"
        "=== END QCL_NATIVE_CRASH ===\n", "Unity: IndexOutOfRangeException\nat Player.cs:12\n");
    assert(legacy.find("0x123") != std::string::npos && legacy.find("Player.cs:12") != std::string::npos);
    assert(legacy.find("x0=") == std::string::npos && legacy.find("raw memory map") == std::string::npos);

    qcl::AndroidExit anr{6, 0, 42, 1700000000000LL, "test.game", "Input dispatch timed out",
        "----- pid 42 -----\n\"main\" prio=5 tid=1\n  at Game.Wait(Game.java:73)\n"
        "\"other\" prio=4 tid=2\n  at Irrelevant.Work(Other.java:90)\n"};
    const auto anr_report = qcl::FormatAndroidExit(anr, "");
    assert(anr_report.find("Game.java:73") != std::string::npos);
    assert(anr_report.find("Other.java:90") == std::string::npos);
    assert(qcl::IsCrashExit(3) && !qcl::IsCrashExit(10));
    std::puts("{\"result\":\"passed\",\"checks\":[\"AOSP tombstone fields and crashing thread\","
              "\"zero fault address\",\"native function demangling\",\"game source-line strings retained\","
              "\"unknown fields tolerated\",\"malformed and truncated protobuf bounded\","
              "\"clean native and legacy reports\",\"ANR main-thread source location\","
              "\"logger boilerplate removed\"]}");
}
