#include "native_report.hpp"
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <signal.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <thread>
#include <unistd.h>
#include <vector>

int chain_fd = -1;
void *expected_fault = nullptr;
void PreviousHandler(int) {
    const char message[] = "previous-handler-ran\n";
    write(chain_fd, message, sizeof(message) - 1);
    _exit(73);
}

void PreviousFaultHandler(int signal, siginfo_t *info, void *context) {
    _exit(signal == SIGSEGV && info && info->si_addr == expected_fault && context ? 74 : 75);
}

int main(int argc, char **argv) {
    if (argc < 3) return 2;
    rlimit core{0, 0};
    setrlimit(RLIMIT_CORE, &core);
    const char *mode = argv[2];
    if (!std::strcmp(mode, "ignored-trap")) signal(SIGTRAP, SIG_IGN);
    if (!std::strcmp(mode, "ignored-abort")) signal(SIGABRT, SIG_IGN);
    if (!std::strcmp(mode, "chain")) {
        char path[4096];
        std::snprintf(path, sizeof(path), "%s/chain.txt", argv[1]);
        chain_fd = open(path, O_CREAT | O_WRONLY | O_CLOEXEC, 0600);
        struct sigaction previous{};
        previous.sa_handler = PreviousHandler;
        sigemptyset(&previous.sa_mask);
        sigaction(SIGABRT, &previous, nullptr);
    }
    if (!std::strcmp(mode, "chain-segv")) {
        struct sigaction previous{};
        previous.sa_sigaction = PreviousFaultHandler;
        previous.sa_flags = SA_SIGINFO;
        sigemptyset(&previous.sa_mask);
        sigaction(SIGSEGV, &previous, nullptr);
    }
    const bool deferred = !std::strcmp(mode, "deferred-chain");
    if (!qcl::InitializeNative(argv[1], "test.quest.logger", !deferred)) return 3;
    if (deferred) {
        char path[4096];
        std::snprintf(path, sizeof(path), "%s/chain.txt", argv[1]);
        chain_fd = open(path, O_CREAT | O_WRONLY | O_CLOEXEC, 0600);
        struct sigaction game{};
        game.sa_handler = PreviousHandler;
        sigemptyset(&game.sa_mask);
        sigaction(SIGABRT, &game, nullptr);
        qcl::ArmNativeHandlers();
    }
    qcl::RefreshNativeModules();
    if (argc > 3) {
        int fd = open(argv[3], O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0600);
        if (fd < 0 || !qcl::CopyReport(qcl::PrivateReportPath(), fd)) return 4;
        qcl::SetDownloadFd(fd);
    }
    const char message[] = "[Unity Exception] native-test-sentinel\nat Example.Throw()";
    qcl::AddLog(message, sizeof(message) - 1);
    if (!std::strcmp(mode, "healthy")) { qcl::Flush(); return 0; }
    if (!std::strcmp(mode, "ignored-trap")) { raise(SIGTRAP); return 0; }
    if (!std::strcmp(mode, "ignored-abort")) { raise(SIGABRT); return 0; }
    if (!std::strcmp(mode, "segv") || !std::strcmp(mode, "chain-segv")) {
        void *page = mmap(nullptr, 4096, PROT_NONE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        expected_fault = page;
        *static_cast<volatile char *>(page) = 1;
    }
    if (!std::strcmp(mode, "kill")) raise(SIGKILL);
    if (!std::strcmp(mode, "bus")) raise(SIGBUS);
    if (!std::strcmp(mode, "ill")) raise(SIGILL);
    if (!std::strcmp(mode, "fpe")) raise(SIGFPE);
    if (!std::strcmp(mode, "trap")) raise(SIGTRAP);
    if (!std::strcmp(mode, "stress")) {
        std::vector<std::jthread> threads;
        for (unsigned i = 0; i < 8; ++i)
            threads.emplace_back([i] {
                char line[256];
                for (unsigned n = 0; ; ++n) {
                    const int length = std::snprintf(line, sizeof(line), "writer=%u count=%u\nsafe-content", i, n);
                    qcl::AddLog(line, static_cast<unsigned>(length));
                }
            });
        usleep(30000);
        raise(SIGABRT);
        return 5;
    }
    raise(SIGABRT);
    return 6;
}
