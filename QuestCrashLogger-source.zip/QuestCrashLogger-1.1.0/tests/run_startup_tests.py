#!/usr/bin/env python3
"""Check startup and actual JNI export control flow with strict host doubles."""
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
ndk = Path(os.environ["ANDROID_NDK_HOME"])
jni = next(ndk.glob("toolchains/llvm/prebuilt/*/sysroot/usr/include/jni.h"))
with tempfile.TemporaryDirectory(prefix="qcl-startup-tests-") as directory:
    directory = Path(directory)
    include = directory / "include"
    shutil.copytree(root / "tests/host_include", include)
    shutil.copyfile(jni, include / "jni.h")
    harness = directory / "harness"
    subprocess.run([
        os.environ.get("CXX", "g++"), "-std=c++20", "-O2", "-pthread",
        "-Wall", "-Wextra", "-I", str(include), "-I", str(root / "src"),
        "-I", str(root / "include"),
        str(root / "src/entry.cpp"), str(root / "src/native_report.cpp"),
        str(root / "src/android_support.cpp"), str(root / "src/android_exit.cpp"),
        str(root / "src/crash_format.cpp"), str(root / "tests/startup_harness.cpp"),
        "-Wl,--wrap=pthread_create", "-o", str(harness),
    ], check=True)
    reports = directory / "reports"
    reports.mkdir()
    subprocess.run([str(harness), str(reports)], check=True, timeout=15)
