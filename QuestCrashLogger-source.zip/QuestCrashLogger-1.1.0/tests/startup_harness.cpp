#include "QuestCrashLogger.h"
#include "native_report.hpp"
#include "android_support.hpp"
#include "crash_format.hpp"
#include <cassert>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <chrono>
#include <deque>
#include <fstream>
#include <map>
#include <pthread.h>
#include <string>
#include <sys/resource.h>
#include <unistd.h>
#include <vector>

/* These doubles exercise the actual entry/MediaStore C++ code, including JNI
 * argument arrays and pending-exception discipline. They do not simulate a
 * physical Quest or prove Android's real MediaProvider behavior. */
constinit unsigned thread_requests = 0;
constinit unsigned unity_requests = 0;
bool pending = false;
bool failure_triggered = false;
std::string fail_at, shared_path;
unsigned method_index = 1, updates = 0, deletes = 0;
std::map<jmethodID, std::string> methods;
int publish_result = 1;
bool history_enabled = false;
std::int64_t historical_time = 0;
std::deque<_jstring> java_strings;
std::map<jobject, std::string> text;
std::string display_name;
std::vector<std::string> published_names, published_text;
_jstring fake_description;
_jclass fake_class;
_jobject fake_object;
_jstring fake_string;
JavaVM fake_vm{};

void Guard() { assert(!pending && "A regular JNI call was made with a pending exception"); }
bool Fail(const std::string &operation) {
    Guard();
    if (operation != fail_at) return false;
    pending = true;
    failure_triggered = true;
    return true;
}
extern "C" int __wrap_pthread_create(pthread_t *, const pthread_attr_t *,
                                    void *(*)(void *), void *) {
    ++thread_requests;
    return EAGAIN; // Keep every test deterministic; no host worker is launched.
}
extern "C" int __android_log_print(int, const char *, const char *, ...) { return 0; }
extern "C" int android_get_device_api_level() { return 32; }
namespace qcl {
bool EnableUnityCapture(unsigned) { ++unity_requests; return false; }
}

jclass FindClass(JNIEnv *, const char *name) {
    return Fail(std::string("class:") + name) ? nullptr : &fake_class;
}
jmethodID GetMethod(JNIEnv *, jclass, const char *name, const char *) {
    if (Fail(std::string("method:") + name)) return nullptr;
    auto id = reinterpret_cast<jmethodID>(static_cast<std::uintptr_t>(method_index++));
    methods[id] = name;
    return id;
}
jobject CallObjectV(JNIEnv *, jobject, jmethodID method, va_list) {
    Guard();
    if (methods.at(method) == "getPackageName" || methods.at(method) == "getProcessName") return &fake_string;
    if (methods.at(method) == "getDescription") return &fake_description;
    if (methods.at(method) == "getTraceInputStream") return nullptr;
    return &fake_object;
}
jobject CallObjectA(JNIEnv *, jobject, jmethodID, const jvalue *args) {
    Guard(); assert(args); return &fake_object;
}
jobject CallStaticObjectA(JNIEnv *, jclass, jmethodID method, const jvalue *args) {
    Guard(); assert(methods.at(method) == "valueOf" && args);
    return &fake_object;
}
jint CallIntV(JNIEnv *, jobject, jmethodID method, va_list) {
    Guard();
    const auto &name = methods.at(method);
    if (name == "size") return history_enabled ? 1 : 0;
    if (name == "getReason") return 5;
    if (name == "getStatus") return 11;
    if (name == "getPid") return 77771;
    assert(name == "detachFd");
    return open(shared_path.c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0600);
}
jint CallIntA(JNIEnv *, jobject, jmethodID method, const jvalue *args) {
    Guard(); assert(args && args[0].l);
    if (methods.at(method) == "update") {
        ++updates;
        assert(args[1].l && !args[2].l && !args[3].l);
        if (publish_result > 0) {
            published_names.push_back(display_name);
            published_text.push_back(qcl::ReadSmallFile(shared_path));
        }
        return publish_result;
    }
    assert(methods.at(method) == "delete");
    ++deletes;
    unlink(shared_path.c_str());
    return 1;
}
void CallVoidA(JNIEnv *, jobject, jmethodID method, const jvalue *args) {
    Guard(); assert(methods.at(method) == "put" && args && args[0].l && args[1].l);
    if (text[args[0].l] == "_display_name") display_name = text.at(args[1].l);
}
void Reset(const char *failure) {
    assert(!pending);
    fail_at = failure;
    failure_triggered = false;
}

int main(int argc, char **argv) {
    assert(argc == 2);
    rlimit core{0, 0}; setrlimit(RLIMIT_CORE, &core);
    assert(thread_requests == 0 && unity_requests == 0);
    assert(JNI_OnLoad(nullptr, nullptr) == JNI_ERR);
    assert(QuestCrashLogger_EnableUnityCapture(222) == 0 && unity_requests == 0);
    assert(QuestCrashLogger_Initialize(nullptr, nullptr) == 0);
    assert(qcl::InitializeNative(argv[1], "test.quest.logger"));
    shared_path = std::string(argv[1]) + "/mediastore-provider-double.txt";
    text[&fake_string] = "test.quest.logger";
    text[&fake_description] = "Native crash recorded by Android";

    JNINativeInterface table{};
    table.ExceptionCheck = [](JNIEnv *) -> jboolean { return pending ? JNI_TRUE : JNI_FALSE; };
    table.ExceptionDescribe = [](JNIEnv *) {};
    table.ExceptionClear = [](JNIEnv *) { pending = false; };
    table.GetJavaVM = [](JNIEnv *, JavaVM **vm) -> jint { Guard(); *vm = &fake_vm; return JNI_OK; };
    table.PushLocalFrame = [](JNIEnv *, jint) -> jint { Guard(); return JNI_OK; };
    table.PopLocalFrame = [](JNIEnv *, jobject) -> jobject { Guard(); return nullptr; };
    table.FindClass = FindClass;
    table.GetMethodID = GetMethod;
    table.GetStaticMethodID = GetMethod;
    table.CallObjectMethodV = CallObjectV;
    table.CallObjectMethodA = CallObjectA;
    table.CallStaticObjectMethodA = CallStaticObjectA;
    table.CallIntMethodV = CallIntV;
    table.CallLongMethodV = [](JNIEnv *, jobject, jmethodID method, va_list) -> jlong {
        Guard(); assert(methods.at(method) == "getTimestamp"); return historical_time;
    };
    table.NewGlobalRef = [](JNIEnv *, jobject object) -> jobject { Guard(); return object; };
    table.CallIntMethodA = CallIntA;
    table.CallVoidMethodA = CallVoidA;
    table.GetObjectClass = [](JNIEnv *, jobject) -> jclass { Guard(); return &fake_class; };
    table.NewObjectV = [](JNIEnv *, jclass, jmethodID, va_list) -> jobject { Guard(); return &fake_object; };
    table.GetStaticFieldID = [](JNIEnv *, jclass, const char *, const char *) -> jfieldID {
        Guard(); return reinterpret_cast<jfieldID>(1);
    };
    table.GetStaticObjectField = [](JNIEnv *, jclass, jfieldID) -> jobject { Guard(); return &fake_object; };
    table.NewStringUTF = [](JNIEnv *, const char *value) -> jstring {
        Guard(); java_strings.emplace_back();
        jstring object = &java_strings.back(); text[object] = value; return object;
    };
    table.GetStringUTFChars = [](JNIEnv *, jstring value, jboolean *) -> const char * {
        Guard(); return text.at(value).c_str();
    };
    table.ReleaseStringUTFChars = [](JNIEnv *, jstring, const char *) { Guard(); };
    table.DeleteLocalRef = [](JNIEnv *, jobject) { Guard(); };
    JNIEnv env{&table};

    pending = true;
    assert(QuestCrashLogger_Initialize(&env, &fake_object) == 0);
    assert(pending); // The initializer must preserve an exception owned by its caller.
    pending = false;
    const char *failures[] = {
        "class:android/content/Context", "class:java/io/File",
        "method:getPackageName", "method:getFilesDir", "method:getAbsolutePath",
        "class:android/provider/MediaStore$Downloads", "class:android/content/ContentValues",
        "method:insert", "method:openFileDescriptor", "method:update"
    };
    for (const char *failure : failures) {
        Reset(failure);
        assert(QuestCrashLogger_Initialize(&env, &fake_object) == 0);
        assert(failure_triggered && !pending);
        assert(!(QuestCrashLogger_GetStatus() & QCL_DOWNLOADS_READY));
        assert(*QuestCrashLogger_GetLastError());
        assert(unity_requests == 0);
    }
    Reset("");
    publish_result = 0;
    assert(QuestCrashLogger_Initialize(&env, &fake_object) == 0);
    assert(!(QuestCrashLogger_GetStatus() & QCL_DOWNLOADS_READY));
    assert(updates == 1 && deletes == 1 && access(shared_path.c_str(), F_OK) != 0);

    publish_result = 1;
    assert(QuestCrashLogger_Initialize(&env, &fake_object) == 1);
    assert(QuestCrashLogger_GetStatus() & QCL_DOWNLOADS_READY);
    assert(!*QuestCrashLogger_GetLastError());
    assert(updates == 2 && thread_requests > 0 && unity_requests == 0);
    assert(published_names.size() == 1 && published_names[0] == "test.txt");
    assert(published_text[0] == "QuestCrashLogger\nCrash logging is enabled.\n");
    assert(QuestCrashLogger_Initialize(&env, &fake_object) == 1);
    assert(qcl::PrepareDownloads(&env, &fake_object, "test.quest.logger"));
    assert(published_names.size() == 1); // The disk marker survives a new initialization.

    const auto now = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    historical_time = now - 60000;
    const std::string old_session = std::string(argv[1]) + "/QuestCrash-" +
        std::to_string((now - 120000) / 1000) + "-000000001-77771.txt";
    std::ofstream(old_session) << "QCL private session\n"; // Game replaced our handler: no native marker.
    std::ofstream(old_session + ".logcat") << "Unity: NullReferenceException: player missing\n"
        "at Player.Update() (at Player.cs:37)\n";
    history_enabled = true;
    assert(qcl::PrepareDownloads(&env, &fake_object, "test.quest.logger"));
    assert(published_names.size() == 2 && published_names.back().starts_with("crash-"));
    assert(published_text.back().find("Native code crash") != std::string::npos);
    assert(published_text.back().find("Player.cs:37") != std::string::npos);
    assert(qcl::PrepareDownloads(&env, &fake_object, "test.quest.logger"));
    assert(published_names.size() == 2); // Same Android exit is not exported twice.

    history_enabled = false;
    const std::string native_session = std::string(argv[1]) + "/QuestCrash-" +
        std::to_string((now - 30000) / 1000) + "-000000001-77772.txt";
    std::ofstream(native_session) << "QCL private session\n=== QCL_NATIVE_CRASH ===\n"
        "Game crash\nProcess: test.quest.logger\nCrash: SIGSEGV\nReason: Invalid memory access\n"
        "\nNative stack:\n  #00 pc 0x1234 libgame.so\n\nGame logs:\nGame: final message\n"
        "=== END QCL_NATIVE_CRASH ===\n";
    assert(qcl::PrepareDownloads(&env, &fake_object, "test.quest.logger"));
    assert(published_names.size() == 3 && published_names.back().starts_with("crash-"));
    assert(published_text.back().find("libgame.so") != std::string::npos);
    assert(published_text.back().find("QCL_NATIVE_CRASH") == std::string::npos);
    assert(published_text.back().find("BNM:") == std::string::npos);
    assert(qcl::PrepareDownloads(&env, &fake_object, "test.quest.logger"));
    assert(published_names.size() == 3 && unity_requests == 0);
    std::puts("{\"result\":\"passed\",\"platform\":\"Linux host with strict JNI/provider doubles\","
              "\"checks\":[\"no constructor worker or Unity hook\",\"caller exception preserved\","
              "\"10 JNI lookup failures stop immediately\",\"failed publication cleaned up\","
              "\"test exported once across repeated initialization\","
              "\"Android crash recovered without a native signal record\","
              "\"saved game logs and source-line text included\",\"native report fallback recovered\","
              "\"each crash exported once\",\"reports exclude logger boilerplate\"]}");
}
