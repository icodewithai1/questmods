#pragma once
/* Host-test declarations only; production uses the NDK header. */
#define ANDROID_LOG_ERROR 6
#define ANDROID_LOG_WARN 5
#ifdef __cplusplus
extern "C" {
#endif
int __android_log_print(int priority, const char *tag, const char *format, ...);
#ifdef __cplusplus
}
#endif
