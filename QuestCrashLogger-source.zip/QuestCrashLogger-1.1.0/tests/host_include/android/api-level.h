#pragma once
/* Host-test declaration only; production uses libandroid. */
#ifdef __cplusplus
extern "C" {
#endif
int android_get_device_api_level(void);
#ifdef __cplusplus
}
#endif
