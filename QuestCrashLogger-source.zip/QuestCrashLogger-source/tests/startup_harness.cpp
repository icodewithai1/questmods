#include "QuestCrashLogger.h"
#include "native_report.hpp"
#include <cassert>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <fstream>
#include <map>
#include <pthread.h>
#include <string>
#include <sys/resource.h>
#include <unistd.h>

/* These doubles exercise the actual entry/MediaStore C++ code, including JNI
 * argument arrays and pending-exception discipline. They do not simulate a
 * physical Quest or prove Android's real MediaProvider behavior. */
constinit unsigned thread_requests = 0;
constinit unsigned unity_requests = 0;
bool pending = false;
bool failure_triggered = false;
std::string fail_at, shared_path;
unsigned method_index = 1, updates = 0, deletes = 0;
std::map<jmethodID, std::string> methods;
int publish_result = 1;
_jclass fake_class;
_jobject fake_object;
_jstring fake_string;
JavaVM fake_vm{};

void Guard() { assert(!pending && "A regular JNI call was made with a pending exception"); }
bool Fail(const std::string &operation) {
    Guard();
    if (operation != fail_at) return false;
    pending = true;
    failure_triggered = true;
    return true;
}
extern "C" int __wrap_pthread_create(pthread_t *, const pthread_attr_t *,
                                    void *(*)(void *), void *) {
    ++thread_requests;
    return EAGAIN; // Keep every test deterministic; no host worker is launched.
}
extern "C" int __android_log_print(int, const char *, const char *, ...) { return 0; }
extern "C" int android_get_device_api_level() { return 32; }
namespace qcl {
bool EnableUnityCapture(unsigned) { ++unity_requests; return false; }
}

jclass FindClass(JNIEnv *, const char *name) {
    return Fail(std::string("class:") + name) ? nullptr : &fake_class;
}
jmethodID GetMethod(JNIEnv *, jclass, const char *name, const char *) {
    if (Fail(std::string("method:") + name)) return nullptr;
    auto id = reinterpret_cast<jmethodID>(static_cast<std::uintptr_t>(method_index++));
    methods[id] = name;
    return id;
}
jobject CallObjectV(JNIEnv *, jobject, jmethodID method, va_list) {
    Guard();
    if (methods.at(method) == "getPackageName") return &fake_string;
    return &fake_object;
}
jobject CallObjectA(JNIEnv *, jobject, jmethodID, const jvalue *args) {
    Guard(); assert(args); return &fake_object;
}
jobject CallStaticObjectA(JNIEnv *, jclass, jmethodID method, const jvalue *args) {
    Guard(); assert(methods.at(method) == "valueOf" && args);
    return &fake_object;
}
jint CallIntV(JNIEnv *, jobject, jmethodID method, va_list) {
    Guard(); assert(methods.at(method) == "detachFd");
    return open(shared_path.c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0600);
}
jint CallIntA(JNIEnv *, jobject, jmethodID method, const jvalue *args) {
    Guard(); assert(args && args[0].l);
    if (methods.at(method) == "update") {
        ++updates;
        assert(args[1].l && !args[2].l && !args[3].l);
        return publish_result;
    }
    assert(methods.at(method) == "delete");
    ++deletes;
    unlink(shared_path.c_str());
    return 1;
}
void CallVoidA(JNIEnv *, jobject, jmethodID method, const jvalue *args) {
    Guard(); assert(methods.at(method) == "put" && args && args[0].l && args[1].l);
}
void Reset(const char *failure) {
    assert(!pending);
    fail_at = failure;
    failure_triggered = false;
}

int main(int argc, char **argv) {
    assert(argc == 2);
    rlimit core{0, 0}; setrlimit(RLIMIT_CORE, &core);
    assert(thread_requests == 0 && unity_requests == 0);
    assert(JNI_OnLoad(nullptr, nullptr) == JNI_ERR);
    assert(QuestCrashLogger_EnableUnityCapture(222) == 0 && unity_requests == 0);
    assert(QuestCrashLogger_Initialize(nullptr, nullptr) == 0);
    assert(qcl::InitializeNative(argv[1], "test.quest.logger"));
    shared_path = std::string(argv[1]) + "/mediastore-provider-double.txt";

    JNINativeInterface table{};
    table.ExceptionCheck = [](JNIEnv *) -> jboolean { return pending ? JNI_TRUE : JNI_FALSE; };
    table.ExceptionDescribe = [](JNIEnv *) {};
    table.ExceptionClear = [](JNIEnv *) { pending = false; };
    table.GetJavaVM = [](JNIEnv *, JavaVM **vm) -> jint { Guard(); *vm = &fake_vm; return JNI_OK; };
    table.PushLocalFrame = [](JNIEnv *, jint) -> jint { Guard(); return JNI_OK; };
    table.PopLocalFrame = [](JNIEnv *, jobject) -> jobject { Guard(); return nullptr; };
    table.FindClass = FindClass;
    table.GetMethodID = GetMethod;
    table.GetStaticMethodID = GetMethod;
    table.CallObjectMethodV = CallObjectV;
    table.CallObjectMethodA = CallObjectA;
    table.CallStaticObjectMethodA = CallStaticObjectA;
    table.CallIntMethodV = CallIntV;
    table.CallIntMethodA = CallIntA;
    table.CallVoidMethodA = CallVoidA;
    table.GetObjectClass = [](JNIEnv *, jobject) -> jclass { Guard(); return &fake_class; };
    table.NewObjectV = [](JNIEnv *, jclass, jmethodID, va_list) -> jobject { Guard(); return &fake_object; };
    table.GetStaticFieldID = [](JNIEnv *, jclass, const char *, const char *) -> jfieldID {
        Guard(); return reinterpret_cast<jfieldID>(1);
    };
    table.GetStaticObjectField = [](JNIEnv *, jclass, jfieldID) -> jobject { Guard(); return &fake_object; };
    table.NewStringUTF = [](JNIEnv *, const char *) -> jstring { Guard(); return &fake_string; };
    table.GetStringUTFChars = [](JNIEnv *, jstring, jboolean *) -> const char * { Guard(); return "test.quest.logger"; };
    table.ReleaseStringUTFChars = [](JNIEnv *, jstring, const char *) { Guard(); };
    table.DeleteLocalRef = [](JNIEnv *, jobject) { Guard(); };
    JNIEnv env{&table};

    pending = true;
    assert(QuestCrashLogger_Initialize(&env, &fake_object) == 0);
    assert(pending); // The initializer must preserve an exception owned by its caller.
    pending = false;
    const char *failures[] = {
        "class:android/content/Context", "class:java/io/File",
        "method:getPackageName", "method:getFilesDir", "method:getAbsolutePath",
        "class:android/provider/MediaStore$Downloads", "class:android/content/ContentValues",
        "method:insert", "method:openFileDescriptor", "method:update"
    };
    for (const char *failure : failures) {
        Reset(failure);
        assert(QuestCrashLogger_Initialize(&env, &fake_object) == 0);
        assert(failure_triggered && !pending);
        assert(!(QuestCrashLogger_GetStatus() & QCL_DOWNLOADS_READY));
        assert(*QuestCrashLogger_GetLastError());
        assert(unity_requests == 0 && thread_requests == 0);
    }
    Reset("");
    publish_result = 0;
    assert(QuestCrashLogger_Initialize(&env, &fake_object) == 0);
    assert(!(QuestCrashLogger_GetStatus() & QCL_DOWNLOADS_READY));
    assert(updates == 1 && deletes == 1 && access(shared_path.c_str(), F_OK) != 0);

    publish_result = 1;
    assert(QuestCrashLogger_Initialize(&env, &fake_object) == 1);
    assert(QuestCrashLogger_GetStatus() & QCL_DOWNLOADS_READY);
    assert(!*QuestCrashLogger_GetLastError());
    assert(updates == 2 && thread_requests == 1 && unity_requests == 0);
    std::ifstream exported(shared_path);
    std::string first_line;
    std::getline(exported, first_line);
    assert(first_line.find("QuestCrashLogger 1.0.1") != std::string::npos);
    assert(QuestCrashLogger_Initialize(&env, &fake_object) == 1);
    assert(updates == 2 && thread_requests == 1 && unity_requests == 0);
    std::puts("{\"result\":\"passed\",\"platform\":\"Linux host with strict JNI/provider doubles\","
              "\"checks\":[\"no constructor worker or Unity hook\",\"caller exception preserved\","
              "\"10 JNI lookup failures stop immediately\",\"failed publish is not success\","
              "\"failed pending row cleaned up\",\"successful export copies report and sets ready\","
              "\"initialization is idempotent\",\"Unity hook remains opt-in\"]}");
}
