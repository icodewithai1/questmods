cmake_minimum_required(VERSION 3.22...3.31)
project(QuestCrashLogger VERSION 1.0.1 LANGUAGES C CXX ASM)

if(NOT ANDROID OR NOT ANDROID_ABI STREQUAL "arm64-v8a")
  message(FATAL_ERROR "Build with the Android NDK toolchain and ANDROID_ABI=arm64-v8a.")
endif()
if(ANDROID_PLATFORM_LEVEL LESS 29)
  message(FATAL_ERROR "Android API 29 or later is required for MediaStore Downloads.")
endif()

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)
set(CMAKE_CXX_VISIBILITY_PRESET hidden)
set(CMAKE_VISIBILITY_INLINES_HIDDEN ON)
set(QCL_UNITY_VER "222" CACHE STRING "BNM Unity header selector (222 = Unity 2022.2/2022.3)")
if(NOT QCL_UNITY_VER MATCHES "^[0-9]+$")
  message(FATAL_ERROR "QCL_UNITY_VER must be a numeric BNM Unity header selector.")
endif()

set(DOBBY_DEBUG OFF CACHE BOOL "" FORCE)
set(DOBBY_BUILD_EXAMPLE OFF CACHE BOOL "" FORCE)
set(DOBBY_BUILD_TEST OFF CACHE BOOL "" FORCE)
set(Plugin.SymbolResolver OFF CACHE BOOL "" FORCE)
add_subdirectory(third_party/dobby EXCLUDE_FROM_ALL)
add_subdirectory(third_party/bnm EXCLUDE_FROM_ALL)
target_include_directories(BNM PUBLIC third_party/dobby/include)
target_compile_definitions(BNM PUBLIC UNITY_VER=${QCL_UNITY_VER} NDEBUG)
target_compile_options(BNM PRIVATE -ffunction-sections -fdata-sections)

add_library(questcrashlogger SHARED
  src/entry.cpp
  src/native_report.cpp
  src/android_support.cpp
  src/unity_capture.cpp
)
target_include_directories(questcrashlogger PUBLIC include PRIVATE src)
target_compile_options(questcrashlogger PRIVATE
  -Wall -Wextra -Wformat=2 -fstack-protector-strong
  -ffunction-sections -fdata-sections -fno-omit-frame-pointer
)
target_link_libraries(questcrashlogger PRIVATE BNM dobby_static log android dl)
target_link_options(questcrashlogger PRIVATE
  "-Wl,--version-script=${CMAKE_CURRENT_SOURCE_DIR}/cmake/exports.map"
  -Wl,--no-undefined
  -Wl,--gc-sections
  -Wl,--exclude-libs,ALL
  -Wl,-z,relro,-z,now,-z,noexecstack
  -Wl,-z,max-page-size=16384
  -Wl,-z,nodelete
)
set_target_properties(questcrashlogger PROPERTIES
  LINK_DEPENDS "${CMAKE_CURRENT_SOURCE_DIR}/cmake/exports.map"
)
