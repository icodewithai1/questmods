#pragma once
#include <jni.h>

#if defined(__cplusplus)
extern "C" {
#endif

#define QCL_API __attribute__((visibility("default")))

enum {
    QCL_NATIVE_READY = 1,
    QCL_DOWNLOADS_READY = 2,
    QCL_UNITY_CAPTURE_READY = 4
};

/* JNIEnv must belong to the calling thread. Returns 1 ONLY after MediaStore
 * publishes a Downloads file and the library retains its descriptor.
 * Returns 0 on failure; GetLastError identifies the failed stage.
 * Call again to retry a failed export.
 */
QCL_API int QuestCrashLogger_Initialize(JNIEnv *env, jobject context);
QCL_API void QuestCrashLogger_SetJavaVM(JavaVM *vm);
QCL_API unsigned QuestCrashLogger_GetStatus(void);
QCL_API const char *QuestCrashLogger_GetLastError(void);
/* Optional: call on an existing IL2CPP game thread after game initialization,
 * with the correct BNM Unity header selector. Never called automatically.
 */
QCL_API int QuestCrashLogger_EnableUnityCapture(unsigned unity_header_version);
QCL_API const char *QuestCrashLogger_GetPrivateReportPath(void);
QCL_API void QuestCrashLogger_Flush(void);

/* The library must remain loaded for the lifetime of the process. */

#if defined(__cplusplus)
}
#endif
