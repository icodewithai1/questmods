#pragma once
#include <cstddef>

namespace qcl {
bool InitializeNative(const char *directory, const char *package_name);
bool NativeReady();
const char *PrivateReportPath();
const char *PrivateDirectory();
void SetDownloadFd(int owned_fd);
void AddLog(const char *text, std::size_t length);
void Note(const char *text);
void Flush();
bool CopyReport(const char *source, int destination);
}
