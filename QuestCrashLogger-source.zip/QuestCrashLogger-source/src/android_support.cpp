#include "android_support.hpp"
#include "native_report.hpp"

#include <android/api-level.h>
#include <android/log.h>
#include <atomic>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <fstream>
#include <iterator>
#include <spawn.h>
#include <signal.h>
#include <string>
#include <sys/wait.h>
#include <unistd.h>

extern char **environ;

namespace qcl {
namespace {
constinit std::atomic<const char *> g_last_error{"Waiting for an Android Context to initialize MediaStore."};

bool Check(JNIEnv *env, const char *stage, bool valid = true) {
    const bool exception = env->ExceptionCheck();
    if (!exception && valid) return true;
    if (exception) {
        env->ExceptionDescribe();
        env->ExceptionClear();
    }
    SetLastError(stage);
    return false;
}

struct LocalFrame {
    JNIEnv *env;
    bool active;
    LocalFrame(JNIEnv *e, int capacity) : env(e), active(e->PushLocalFrame(capacity) == JNI_OK) {
        if (!active) Check(env, "Could not allocate JNI local references.", false);
    }
    ~LocalFrame() { if (active) env->PopLocalFrame(nullptr); }
};

bool Utf8(JNIEnv *env, jstring value, char *destination, std::size_t capacity) {
    if (!value || !destination || !capacity) return false;
    const char *characters = env->GetStringUTFChars(value, nullptr);
    if (!Check(env, "Could not read an Android Context path/name.", characters != nullptr)) return false;
    const int length = std::snprintf(destination, capacity, "%s", characters);
    env->ReleaseStringUTFChars(value, characters);
    if (length < 0 || static_cast<std::size_t>(length) >= capacity) {
        SetLastError("The Context path/name is too long.");
        return false;
    }
    return true;
}

bool PutString(JNIEnv *env, jobject values, const char *key, const char *text) {
    jclass klass = env->GetObjectClass(values);
    if (!Check(env, "ContentValues class lookup failed.", klass != nullptr)) return false;
    jmethodID put = env->GetMethodID(klass, "put", "(Ljava/lang/String;Ljava/lang/String;)V");
    if (!Check(env, "ContentValues.put(String,String) lookup failed.", put != nullptr)) return false;
    jstring k = env->NewStringUTF(key);
    if (!Check(env, "Could not allocate a MediaStore column name.", k != nullptr)) return false;
    jstring v = env->NewStringUTF(text);
    if (!Check(env, "Could not allocate a MediaStore column value.", v != nullptr)) return false;
    jvalue args[2]{};
    args[0].l = k; args[1].l = v;
    env->CallVoidMethodA(values, put, args);
    if (!Check(env, "ContentValues.put(String,String) failed.")) return false;
    env->DeleteLocalRef(k); env->DeleteLocalRef(v); env->DeleteLocalRef(klass);
    return true;
}

bool PutInt(JNIEnv *env, jobject values, const char *key, jint number) {
    jclass klass = env->GetObjectClass(values);
    if (!Check(env, "ContentValues class lookup failed.", klass != nullptr)) return false;
    jclass integers = env->FindClass("java/lang/Integer");
    if (!Check(env, "Integer class lookup failed.", integers != nullptr)) return false;
    jmethodID value_of = env->GetStaticMethodID(integers, "valueOf", "(I)Ljava/lang/Integer;");
    if (!Check(env, "Integer.valueOf lookup failed.", value_of != nullptr)) return false;
    jmethodID put = env->GetMethodID(klass, "put", "(Ljava/lang/String;Ljava/lang/Integer;)V");
    if (!Check(env, "ContentValues.put(String,Integer) lookup failed.", put != nullptr)) return false;
    jvalue number_arg{};
    number_arg.i = number;
    jobject boxed = env->CallStaticObjectMethodA(integers, value_of, &number_arg);
    if (!Check(env, "Integer.valueOf failed.", boxed != nullptr)) return false;
    jstring k = env->NewStringUTF(key);
    if (!Check(env, "Could not allocate the pending-status column name.", k != nullptr)) return false;
    jvalue args[2]{};
    args[0].l = k; args[1].l = boxed;
    env->CallVoidMethodA(values, put, args);
    if (!Check(env, "ContentValues.put(String,Integer) failed.")) return false;
    env->DeleteLocalRef(k); env->DeleteLocalRef(boxed);
    env->DeleteLocalRef(klass); env->DeleteLocalRef(integers);
    return true;
}

/* Normal-thread MediaStore work. Never invoked by the fatal-signal handler. */
int ExportReport(JNIEnv *env, jobject context, const char *package_name, const char *path,
                 const char *display_name = nullptr) {
    if (android_get_device_api_level() < 29) {
        SetLastError("MediaStore Downloads requires Android API 29 or newer.");
        return -1;
    }
    LocalFrame frame(env, 64);
    if (!frame.active) return -1;
    int result = -1, fd = -1;
    jobject resolver = nullptr, uri = nullptr;
    jmethodID remove = nullptr;
    do {
        jclass context_class = env->FindClass("android/content/Context");
        if (!Check(env, "Context class lookup failed.", context_class != nullptr)) break;
        jclass downloads = env->FindClass("android/provider/MediaStore$Downloads");
        if (!Check(env, "MediaStore.Downloads is unavailable.", downloads != nullptr)) break;
        jclass values_class = env->FindClass("android/content/ContentValues");
        if (!Check(env, "ContentValues class lookup failed.", values_class != nullptr)) break;
        jclass resolver_class = env->FindClass("android/content/ContentResolver");
        if (!Check(env, "ContentResolver class lookup failed.", resolver_class != nullptr)) break;
        jmethodID get_resolver = env->GetMethodID(context_class, "getContentResolver", "()Landroid/content/ContentResolver;");
        if (!Check(env, "Context.getContentResolver lookup failed.", get_resolver != nullptr)) break;
        jfieldID collection_field = env->GetStaticFieldID(downloads, "EXTERNAL_CONTENT_URI", "Landroid/net/Uri;");
        if (!Check(env, "MediaStore Downloads URI lookup failed.", collection_field != nullptr)) break;
        jmethodID constructor = env->GetMethodID(values_class, "<init>", "()V");
        if (!Check(env, "ContentValues constructor lookup failed.", constructor != nullptr)) break;
        jmethodID insert = env->GetMethodID(resolver_class, "insert", "(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;");
        if (!Check(env, "ContentResolver.insert lookup failed.", insert != nullptr)) break;
        jmethodID open = env->GetMethodID(resolver_class, "openFileDescriptor", "(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;");
        if (!Check(env, "ContentResolver.openFileDescriptor lookup failed.", open != nullptr)) break;
        jmethodID update = env->GetMethodID(resolver_class, "update", "(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I");
        if (!Check(env, "ContentResolver.update lookup failed.", update != nullptr)) break;
        remove = env->GetMethodID(resolver_class, "delete", "(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I");
        if (!Check(env, "ContentResolver.delete lookup failed.", remove != nullptr)) break;
        resolver = env->CallObjectMethod(context, get_resolver);
        if (!Check(env, "Context.getContentResolver failed.", resolver != nullptr)) break;
        jobject collection = env->GetStaticObjectField(downloads, collection_field);
        if (!Check(env, "MediaStore Downloads collection is null.", collection != nullptr)) break;
        jobject values = env->NewObject(values_class, constructor);
        if (!Check(env, "Could not construct MediaStore ContentValues.", values != nullptr)) break;
        const char *basename = std::strrchr(path, '/');
        const std::string relative = std::string("Download/QuestCrashLogs/") + package_name + "/";
        if (!PutString(env, values, "_display_name", display_name ? display_name : (basename ? basename + 1 : path)) ||
            !PutString(env, values, "mime_type", "text/plain") ||
            !PutString(env, values, "relative_path", relative.c_str()) ||
            !PutInt(env, values, "is_pending", 1)) break;
        jvalue insert_args[2]{};
        insert_args[0].l = collection; insert_args[1].l = values;
        uri = env->CallObjectMethodA(resolver, insert, insert_args);
        if (!Check(env, "MediaStore insert failed or returned no URI. Check storage/provider access.", uri != nullptr)) break;
        jstring mode = env->NewStringUTF("w");
        if (!Check(env, "Could not allocate the MediaStore write mode.", mode != nullptr)) break;
        jvalue open_args[2]{};
        open_args[0].l = uri; open_args[1].l = mode;
        jobject parcel = env->CallObjectMethodA(resolver, open, open_args);
        if (!Check(env, "MediaStore could not open the report for writing.", parcel != nullptr)) break;
        jclass parcel_class = env->FindClass("android/os/ParcelFileDescriptor");
        if (!Check(env, "ParcelFileDescriptor class lookup failed.", parcel_class != nullptr)) break;
        jmethodID detach = env->GetMethodID(parcel_class, "detachFd", "()I");
        if (!Check(env, "ParcelFileDescriptor.detachFd lookup failed.", detach != nullptr)) break;
        fd = env->CallIntMethod(parcel, detach);
        if (!Check(env, "ParcelFileDescriptor.detachFd failed.", fd >= 0)) break;
        fcntl(fd, F_SETFD, FD_CLOEXEC);
        /* The retained open-file description stays at the end after copying.
         * No mandatory F_SETFL/O_APPEND operation on a provider FD is needed. */
        if (!CopyReport(path, fd)) {
            SetLastError("Could not copy the private report into the MediaStore descriptor.");
            break;
        }
        fsync(fd);
        jobject published = env->NewObject(values_class, constructor);
        if (!Check(env, "Could not construct the publish update.", published != nullptr)) break;
        if (!PutInt(env, published, "is_pending", 0)) break;
        jvalue update_args[4]{};
        update_args[0].l = uri; update_args[1].l = published;
        jint updated = env->CallIntMethodA(resolver, update, update_args);
        if (!Check(env, "MediaStore publish failed; the report would remain pending/hidden.", updated > 0)) break;
        result = fd;
    } while (false);
    if (result < 0) {
        if (fd >= 0) close(fd);
        if (resolver && uri && remove) {
            jvalue args[3]{};
            args[0].l = uri;
            env->CallIntMethodA(resolver, remove, args);
            if (env->ExceptionCheck()) env->ExceptionClear();
        }
    }
    return result;
}

bool WasDelivered(const std::string &path) {
    std::ifstream receipt(path + ".delivered");
    return receipt.get() == '1';
}

void ExportPending(JNIEnv *env, jobject context, const char *package_name) {
    DIR *directory = opendir(PrivateDirectory());
    if (!directory) return;
    unsigned attempted = 0;
    while (dirent *entry = readdir(directory)) {
        std::string name(entry->d_name);
        if (!name.starts_with("QuestCrash-") || !name.ends_with(".txt")) continue;
        std::string path = std::string(PrivateDirectory()) + "/" + name;
        if (path == PrivateReportPath() || WasDelivered(path)) continue;
        std::ifstream source(path);
        std::string content((std::istreambuf_iterator<char>(source)), {});
        if (content.find("=== QCL_NATIVE_CRASH ===") == std::string::npos) continue;
        if (++attempted > 32) break;
        int fd = ExportReport(env, context, package_name, path.c_str());
        if (fd >= 0) {
            close(fd);
            std::ofstream(path + ".delivered", std::ios::trunc) << "1";
        }
    }
    closedir(directory);
}
} // namespace

void SetLastError(const char *message) {
    g_last_error.store(message, std::memory_order_release);
    if (*message) {
        Note(message);
        __android_log_print(ANDROID_LOG_ERROR, "QuestCrashLogger", "%s", message);
    }
}

const char *LastError() { return g_last_error.load(std::memory_order_acquire); }

jobject FindApplication(JNIEnv *env) {
    /* Only called from JNI_OnLoad on the existing Java caller. If the OS
     * restricts this fallback, explicit Initialize(env, context) is required. */
    jclass thread = env->FindClass("android/app/ActivityThread");
    if (!Check(env, "Supply a Context explicitly: ActivityThread lookup failed.", thread != nullptr)) return nullptr;
    jmethodID current = env->GetStaticMethodID(thread, "currentApplication", "()Landroid/app/Application;");
    if (!Check(env, "Supply a Context explicitly: currentApplication lookup failed.", current != nullptr)) {
        env->DeleteLocalRef(thread); return nullptr;
    }
    jobject app = env->CallStaticObjectMethod(thread, current);
    bool ok = Check(env, "Supply a Context explicitly: no current Application is available.", app != nullptr);
    env->DeleteLocalRef(thread);
    return ok ? app : nullptr;
}

bool InitializeFromContext(JNIEnv *env, jobject context, char *package_name, unsigned capacity) {
    LocalFrame frame(env, 16);
    if (!frame.active) return false;
    jclass klass = env->FindClass("android/content/Context");
    if (!Check(env, "Context class lookup failed.", klass != nullptr)) return false;
    jclass file = env->FindClass("java/io/File");
    if (!Check(env, "File class lookup failed.", file != nullptr)) return false;
    jmethodID get_package = env->GetMethodID(klass, "getPackageName", "()Ljava/lang/String;");
    if (!Check(env, "Context.getPackageName lookup failed.", get_package != nullptr)) return false;
    jmethodID get_files = env->GetMethodID(klass, "getFilesDir", "()Ljava/io/File;");
    if (!Check(env, "Context.getFilesDir lookup failed.", get_files != nullptr)) return false;
    jmethodID get_path = env->GetMethodID(file, "getAbsolutePath", "()Ljava/lang/String;");
    if (!Check(env, "File.getAbsolutePath lookup failed.", get_path != nullptr)) return false;
    auto package = static_cast<jstring>(env->CallObjectMethod(context, get_package));
    if (!Check(env, "Context.getPackageName failed.", package != nullptr)) return false;
    if (!Utf8(env, package, package_name, capacity)) return false;
    if (NativeReady()) return true;
    jobject files = env->CallObjectMethod(context, get_files);
    if (!Check(env, "Context.getFilesDir failed.", files != nullptr)) return false;
    auto path = static_cast<jstring>(env->CallObjectMethod(files, get_path));
    if (!Check(env, "File.getAbsolutePath failed.", path != nullptr)) return false;
    char directory[4096];
    if (!Utf8(env, path, directory, sizeof(directory) - 32)) return false;
    std::strcat(directory, "/QuestCrashLogger");
    if (!InitializeNative(directory, package_name)) {
        SetLastError("Could not open the app-private native crash report.");
        return false;
    }
    return true;
}

bool PrepareDownloads(JNIEnv *env, jobject context, const char *package_name) {
    if (!NativeReady()) {
        SetLastError("Native report initialization must succeed before MediaStore export.");
        return false;
    }
    ExportPending(env, context, package_name);
    const char *report = PrivateReportPath();
    const char *basename = std::strrchr(report, '/');
    std::string test_name = basename ? basename + 1 : report;
    constexpr char prefix[] = "QuestCrash-";
    if (test_name.starts_with(prefix)) test_name.erase(0, sizeof(prefix) - 1);
    test_name.insert(0, "test-");
    int fd = ExportReport(env, context, package_name, report, test_name.c_str());
    if (fd < 0) return false;
    SetDownloadFd(fd);
    Note("MEDIASTORE_READY: report published in Download/QuestCrashLogs/<package>/ and native FD retained.");
    Flush();
    return true;
}

void CaptureLogcat() {
    int output[2];
    if (pipe2(output, O_CLOEXEC) != 0) return;
    char pid_option[48];
    std::snprintf(pid_option, sizeof(pid_option), "--pid=%d", getpid());
    const char *arguments[] = {"/system/bin/logcat", "-d", "-t", "128", "-v",
                               "threadtime", pid_option, nullptr};
    posix_spawn_file_actions_t actions;
    if (posix_spawn_file_actions_init(&actions) != 0) {
        close(output[0]); close(output[1]); return;
    }
    posix_spawn_file_actions_adddup2(&actions, output[1], STDOUT_FILENO);
    posix_spawn_file_actions_adddup2(&actions, output[1], STDERR_FILENO);
    posix_spawn_file_actions_addclose(&actions, output[0]);
    posix_spawn_file_actions_addclose(&actions, output[1]);
    pid_t child = -1;
    const int error = posix_spawn(&child, arguments[0], &actions, nullptr,
                                  const_cast<char *const *>(arguments), environ);
    posix_spawn_file_actions_destroy(&actions);
    close(output[1]);
    if (error == 0) {
        /* Bounded output and a nonblocking read keep a hung logcat from
         * blocking logger startup forever. */
        fcntl(output[0], F_SETFL, O_NONBLOCK);
        char data[4096];
        std::string pending;
        unsigned bytes = 0;
        for (unsigned attempt = 0; attempt < 200 && bytes < 256 * 1024; ++attempt) {
            const ssize_t n = read(output[0], data, sizeof(data));
            if (n == 0) break;
            if (n < 0) {
                if (errno != EAGAIN && errno != EINTR) break;
                timespec pause{0, 10 * 1000 * 1000};
                nanosleep(&pause, nullptr);
                continue;
            }
            bytes += static_cast<unsigned>(n);
            pending.append(data, static_cast<std::size_t>(n));
            std::size_t position;
            while ((position = pending.find('\n')) != std::string::npos) {
                AddLog(pending.data(), position);
                pending.erase(0, position + 1);
            }
            if (pending.size() > sizeof(data)) {
                AddLog(pending.data(), sizeof(data));
                pending.clear();
            }
        }
        if (!pending.empty()) AddLog(pending.data(), pending.size());
        /* Only our own child is terminated if it outlives the snapshot. */
        int status;
        if (waitpid(child, &status, WNOHANG) == 0) {
            kill(child, SIGKILL);
            while (waitpid(child, &status, 0) < 0 && errno == EINTR) {}
        }
    }
    close(output[0]);
}
} // namespace qcl
