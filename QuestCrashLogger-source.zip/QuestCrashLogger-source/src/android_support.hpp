#pragma once
#include <jni.h>

namespace qcl {
jobject FindApplication(JNIEnv *env);
void SetLastError(const char *static_message);
const char *LastError();
bool InitializeFromContext(JNIEnv *env, jobject context, char *package_name, unsigned capacity);
bool PrepareDownloads(JNIEnv *env, jobject context, const char *package_name);
void CaptureLogcat();
bool EnableUnityCapture(unsigned unity_header_version);
}
