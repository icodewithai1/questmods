#include "QuestCrashLogger.h"
#include "android_support.hpp"
#include "native_report.hpp"

#include <android/log.h>
#include <atomic>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <pthread.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

namespace {
constinit std::atomic<JavaVM *> g_vm{nullptr};
constinit std::atomic<bool> g_downloads_ready{false};
constinit std::atomic<bool> g_unity_ready{false};
constinit std::atomic<bool> g_logcat_started{false};
pthread_once_t g_start_once = PTHREAD_ONCE_INIT;
pthread_mutex_t g_initialization = PTHREAD_MUTEX_INITIALIZER;
char g_package[256] = "unknown";

struct InitializationLock {
    InitializationLock() { pthread_mutex_lock(&g_initialization); }
    ~InitializationLock() { pthread_mutex_unlock(&g_initialization); }
};

void StartNative() {
    char command[256]{};
    const int fd = open("/proc/self/cmdline", O_RDONLY | O_CLOEXEC);
    if (fd < 0) return;
    const ssize_t bytes = read(fd, command, sizeof(command) - 1);
    close(fd);
    if (bytes <= 0) return;
    if (char *suffix = std::strchr(command, ':')) *suffix = '\0';
    bool valid = std::strchr(command, '.') != nullptr;
    for (const unsigned char *p = reinterpret_cast<unsigned char *>(command); *p; ++p)
        if (!std::isalnum(*p) && *p != '.' && *p != '_') valid = false;
    if (!valid) return;
    std::snprintf(g_package, sizeof(g_package), "%s", command);
    char path[512];
    const unsigned profile = static_cast<unsigned>(getuid()) / 100000;
    std::snprintf(path, sizeof(path), "/data/user/%u/%s/files", profile, g_package);
    mkdir(path, 0700);
    std::snprintf(path, sizeof(path), "/data/user/%u/%s/files/QuestCrashLogger", profile, g_package);
    if (!qcl::InitializeNative(path, g_package)) {
        std::snprintf(path, sizeof(path), "/data/data/%s/files/QuestCrashLogger", g_package);
        qcl::InitializeNative(path, g_package);
    }
    qcl::Note("Waiting for a Context to initialize MediaStore. Automatic Unity hooking is disabled.");
}

void *LogcatWorker(void *) {
    for (;;) {
        try {
            qcl::CaptureLogcat();
        } catch (...) {
            qcl::Note("An own-process logcat snapshot failed.");
        }
        timespec pause{5, 0};
        nanosleep(&pause, nullptr);
    }
}

/* JNI_OnLoad supplies a real VM and Application from the calling Java thread.
 * No constructor thread probes ART or touches Unity. */
void *InitializeFromJava(void *argument) {
    jobject context = static_cast<jobject>(argument);
    JavaVM *vm = g_vm.load(std::memory_order_acquire);
    if (!vm) return nullptr;
    JNIEnv *env = nullptr;
    JavaVMAttachArgs args{JNI_VERSION_1_6, const_cast<char *>("QuestCrashLogger"), nullptr};
    if (vm->AttachCurrentThreadAsDaemon(&env, &args) != JNI_OK || !env) {
        qcl::SetLastError("Could not attach the MediaStore thread. Call Initialize from an existing JNI thread.");
        return nullptr;
    }
    QuestCrashLogger_Initialize(env, context);
    env->DeleteGlobalRef(context);
    vm->DetachCurrentThread();
    return nullptr;
}

__attribute__((constructor)) void OnLoad() {
    /* POSIX setup only; all C++ initializers finish before any Unity request. */
    pthread_once(&g_start_once, StartNative);
}
} // namespace

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *) {
    if (!vm) return JNI_ERR;
    g_vm.store(vm, std::memory_order_release);
    JNIEnv *env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6) == JNI_OK && env) {
        jobject application = qcl::FindApplication(env);
        if (application) {
            jobject reference = env->NewGlobalRef(application);
            env->DeleteLocalRef(application);
            if (env->ExceptionCheck()) {
                env->ExceptionClear();
                reference = nullptr;
            }
            if (reference) {
                pthread_t worker;
                if (pthread_create(&worker, nullptr, InitializeFromJava, reference) == 0)
                    pthread_detach(worker);
                else {
                    env->DeleteGlobalRef(reference);
                    qcl::SetLastError("Could not start MediaStore initialization. Call Initialize from the loader.");
                }
            }
        }
    }
    return JNI_VERSION_1_6;
}

extern "C" QCL_API int QuestCrashLogger_Initialize(JNIEnv *env, jobject context) {
    if (!env || !context) {
        qcl::SetLastError("Initialize requires the calling thread's JNIEnv and a valid Android Context.");
        return 0;
    }
    if (env->ExceptionCheck()) {
        qcl::SetLastError("Initialize was called with a pending Java exception; resolve it in the caller first.");
        return 0;
    }
    InitializationLock lock;
    if (g_downloads_ready.load(std::memory_order_acquire)) return 1;
    try {
        JavaVM *vm = nullptr;
        if (env->GetJavaVM(&vm) != JNI_OK || !vm) {
            qcl::SetLastError("Could not obtain the Java VM from the supplied JNIEnv.");
            return 0;
        }
        g_vm.store(vm, std::memory_order_release);
        pthread_once(&g_start_once, StartNative);
        qcl::Note("MediaStore initialization started.");
        if (!qcl::InitializeFromContext(env, context, g_package, sizeof(g_package))) return 0;
        if (!qcl::PrepareDownloads(env, context, g_package)) return 0;
        g_downloads_ready.store(true, std::memory_order_release);
        qcl::SetLastError("");
        if (!g_logcat_started.exchange(true, std::memory_order_acq_rel)) {
            pthread_t worker;
            if (pthread_create(&worker, nullptr, LogcatWorker, nullptr) == 0)
                pthread_detach(worker);
            else {
                g_logcat_started.store(false, std::memory_order_release);
                qcl::Note("Downloads is ready; the own-process logcat worker could not start.");
            }
        }
        return 1; // Only after publishing the Downloads row and retaining its FD.
    } catch (...) {
        if (env->ExceptionCheck()) env->ExceptionClear();
        qcl::SetLastError("MediaStore initialization failed with a native exception.");
        return 0;
    }
}

extern "C" QCL_API void QuestCrashLogger_SetJavaVM(JavaVM *vm) {
    if (vm) g_vm.store(vm, std::memory_order_release);
}

extern "C" QCL_API unsigned QuestCrashLogger_GetStatus() {
    unsigned status = qcl::NativeReady() ? QCL_NATIVE_READY : 0;
    if (g_downloads_ready.load(std::memory_order_acquire)) status |= QCL_DOWNLOADS_READY;
    if (g_unity_ready.load(std::memory_order_acquire)) status |= QCL_UNITY_CAPTURE_READY;
    return status;
}

extern "C" QCL_API const char *QuestCrashLogger_GetLastError() { return qcl::LastError(); }

extern "C" QCL_API int QuestCrashLogger_EnableUnityCapture(unsigned unity_header_version) {
    if (!g_downloads_ready.load(std::memory_order_acquire)) {
        qcl::SetLastError("Initialize MediaStore successfully before enabling the optional Unity hook.");
        return 0;
    }
    if (qcl::EnableUnityCapture(unity_header_version)) {
        g_unity_ready.store(true, std::memory_order_release);
        return 1;
    }
    return 0;
}

extern "C" QCL_API const char *QuestCrashLogger_GetPrivateReportPath() {
    return qcl::PrivateReportPath();
}

extern "C" QCL_API void QuestCrashLogger_Flush() { qcl::Flush(); }
