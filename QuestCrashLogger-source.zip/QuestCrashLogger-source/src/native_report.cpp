#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include "native_report.hpp"

#include <atomic>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <time.h>
#include <ucontext.h>
#include <unistd.h>

namespace qcl {
namespace {
constexpr unsigned kSlots = 128;
constexpr unsigned kLineBytes = 4096;
constexpr int kSignals[] = {SIGSEGV, SIGABRT, SIGBUS, SIGILL, SIGFPE, SIGTRAP};
static_assert(std::atomic<unsigned>::is_always_lock_free);
static_assert(std::atomic<int>::is_always_lock_free);
static_assert(std::atomic<unsigned char>::is_always_lock_free);

struct Slot {
    std::atomic<unsigned> busy{0};
    std::atomic<unsigned> sequence{0};
    std::atomic<unsigned> length{0};
    unsigned char bytes[kLineBytes]{};
};
constinit Slot g_slots[kSlots];
constinit std::atomic<unsigned> g_cursor{0};
constinit std::atomic<int> g_private_fd{-1};
constinit std::atomic<int> g_download_fd{-1};
constinit std::atomic<int> g_receipt_fd{-1};
constinit std::atomic<int> g_handling{0};
constinit std::atomic<int> g_ready{0};
char g_path[PATH_MAX]{};
char g_directory[PATH_MAX]{};
struct sigaction g_previous[sizeof(kSignals) / sizeof(kSignals[0])]{};
alignas(16) unsigned char g_alt_stack[64 * 1024]{};

bool WriteAll(int fd, const char *data, std::size_t length) {
    if (fd < 0) return false;
    while (length) {
        const ssize_t n = write(fd, data, length);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) return false;
        data += n;
        length -= static_cast<std::size_t>(n);
    }
    return true;
}

/* Used in the signal handler: fixed storage, no formatting library or heap. */
template<std::size_t N> struct Buffer {
    char bytes[N]{};
    std::size_t size{};
    void Text(const char *s) {
        while (*s && size < N) bytes[size++] = *s++;
    }
    void Unsigned(std::uint64_t value, unsigned base = 10) {
        char reversed[32];
        unsigned count = 0;
        do {
            reversed[count++] = "0123456789abcdef"[value % base];
            value /= base;
        } while (value && count < sizeof(reversed));
        while (count && size < N) bytes[size++] = reversed[--count];
    }
    void Signed(int value) {
        if (value < 0) {
            Text("-");
            Unsigned(static_cast<std::uint64_t>(-static_cast<std::int64_t>(value)));
        } else Unsigned(static_cast<unsigned>(value));
    }
    void Register(const char *label, std::uint64_t value) {
        Text(label);
        Text("=0x");
        Unsigned(value, 16);
        Text("\n");
    }
};

struct Destination {
    int local;
    int downloads;
    bool downloads_ok;
    void Write(const char *data, std::size_t length) {
        WriteAll(local, data, length);
        if (downloads >= 0 && !WriteAll(downloads, data, length)) downloads_ok = false;
    }
    template<std::size_t N> void Literal(const char (&text)[N]) { Write(text, N - 1); }
};

void DumpLogs(Destination &out) {
    out.Literal("\n--- Last captured Unity / own-process logcat messages ---\n");
    const unsigned end = g_cursor.load(std::memory_order_acquire);
    const unsigned start = end > kSlots ? end - kSlots : 0;
    char line[kLineBytes];
    for (unsigned index = start; index < end; ++index) {
        Slot &slot = g_slots[index % kSlots];
        if (slot.busy.load(std::memory_order_acquire)) continue;
        const unsigned sequence = slot.sequence.load(std::memory_order_acquire);
        if (sequence != index + 1) continue;
        unsigned length = slot.length.load(std::memory_order_relaxed);
        if (length > kLineBytes) continue;
        for (unsigned j = 0; j < length; ++j)
            line[j] = static_cast<char>(__atomic_load_n(&slot.bytes[j], __ATOMIC_RELAXED));
        std::atomic_thread_fence(std::memory_order_acquire);
        if (slot.busy.load(std::memory_order_acquire) ||
            slot.sequence.load(std::memory_order_acquire) != sequence) continue;
        out.Write(line, length);
        out.Literal("\n");
    }
}

void DumpMaps(Destination &out) {
    out.Literal("\n--- /proc/self/maps at signal time (maximum 256 KiB) ---\n");
    int fd = open("/proc/self/maps", O_RDONLY | O_CLOEXEC);
    if (fd < 0) {
        out.Literal("Could not open memory maps.\n");
        return;
    }
    char chunk[2048];
    std::size_t total = 0;
    while (total < 256 * 1024) {
        const ssize_t n = read(fd, chunk, sizeof(chunk));
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) break;
        out.Write(chunk, static_cast<std::size_t>(n));
        total += static_cast<std::size_t>(n);
    }
    close(fd);
}

void ForwardSignal(int signal, siginfo_t *info) {
    unsigned index = 0;
    while (index < sizeof(kSignals) / sizeof(kSignals[0]) && kSignals[index] != signal) ++index;
    if (index == sizeof(kSignals) / sizeof(kSignals[0])) _exit(128 + signal);
    struct sigaction previous = g_previous[index];
    if (previous.sa_handler == SIG_IGN && (!info || info->si_code <= 0)) {
        sigaction(signal, &previous, nullptr);
        return;
    }
    if (previous.sa_handler == SIG_IGN) {
        previous.sa_handler = SIG_DFL;
        previous.sa_flags = 0;
    }
    if (sigaction(signal, &previous, nullptr) != 0) _exit(128 + signal);
    /* Retrying a synchronous fault preserves its original siginfo/ucontext for
     * Android's handler, including the original fault address. */
    if (info && info->si_code > 0 &&
        (signal == SIGSEGV || signal == SIGBUS || signal == SIGILL || signal == SIGFPE))
        return;
    /* A raised signal and a breakpoint might not recur on return. Queue it for
     * the original handler; it is delivered after this handler unblocks it. */
    if (syscall(SYS_tgkill, getpid(), syscall(SYS_gettid), signal) != 0)
        _exit(128 + signal);
}

void SignalHandler(int signal, siginfo_t *info, void *context) {
    const int saved_errno = errno;
    for (unsigned i = 0; i < sizeof(kSignals) / sizeof(kSignals[0]); ++i) {
        if (kSignals[i] == signal && g_previous[i].sa_handler == SIG_IGN &&
            (!info || info->si_code <= 0)) {
            ForwardSignal(signal, info);
            errno = saved_errno;
            return;
        }
    }
    if (g_handling.exchange(1, std::memory_order_acq_rel)) {
        ForwardSignal(signal, info);
        errno = saved_errno;
        return;
    }
    Destination out{g_private_fd.load(std::memory_order_relaxed),
                    g_download_fd.load(std::memory_order_relaxed), true};
    Buffer<4096> b;
    timespec now{};
    clock_gettime(CLOCK_REALTIME, &now);
    b.Text("\n=== QCL_NATIVE_CRASH ===\nunix_seconds=");
    b.Unsigned(static_cast<std::uint64_t>(now.tv_sec));
    b.Text("\nnanoseconds=");
    b.Unsigned(static_cast<std::uint64_t>(now.tv_nsec));
    b.Text("\npid=");
    b.Unsigned(static_cast<std::uint64_t>(getpid()));
    b.Text("\ntid=");
    b.Unsigned(static_cast<std::uint64_t>(syscall(SYS_gettid)));
    b.Text("\nsignal=");
    b.Signed(signal);
    b.Text("\nsi_code=");
    b.Signed(info ? info->si_code : 0);
    b.Text("\n");
    if (info && info->si_code > 0 &&
        (signal == SIGSEGV || signal == SIGBUS || signal == SIGILL ||
         signal == SIGFPE || signal == SIGTRAP))
        b.Register("fault_address", reinterpret_cast<std::uintptr_t>(info->si_addr));
    if (context) {
        const auto *uc = static_cast<const ucontext_t *>(context);
#if defined(__aarch64__)
        b.Text("architecture=arm64-v8a\n");
        b.Register("pc", uc->uc_mcontext.pc);
        b.Register("sp", uc->uc_mcontext.sp);
        b.Register("lr", uc->uc_mcontext.regs[30]);
        b.Register("pstate", uc->uc_mcontext.pstate);
        for (unsigned i = 0; i < 31; ++i) {
            b.Text("x");
            b.Unsigned(i);
            b.Text("=0x");
            b.Unsigned(uc->uc_mcontext.regs[i], 16);
            b.Text("\n");
        }
#elif defined(__x86_64__)
        b.Text("architecture=x86_64 (host verification)\n");
        b.Register("pc", uc->uc_mcontext.gregs[REG_RIP]);
        b.Register("sp", uc->uc_mcontext.gregs[REG_RSP]);
        b.Register("bp", uc->uc_mcontext.gregs[REG_RBP]);
#endif
    }
    out.Write(b.bytes, b.size);
    DumpLogs(out);
    DumpMaps(out);
    out.Literal("\n=== END QCL_NATIVE_CRASH ===\n");
    if (out.local >= 0) fsync(out.local);
    if (out.downloads >= 0 && out.downloads_ok && fsync(out.downloads) == 0) {
        const int receipt = g_receipt_fd.load(std::memory_order_relaxed);
        if (receipt >= 0) {
            WriteAll(receipt, "1", 1);
            fsync(receipt);
        }
    }
    g_handling.store(0, std::memory_order_release);
    ForwardSignal(signal, info);
    errno = saved_errno;
}
} // namespace

bool InitializeNative(const char *directory, const char *package_name) {
    if (g_ready.load(std::memory_order_acquire)) return true;
    if (!directory || std::strlen(directory) > PATH_MAX - 160) return false;
    if (mkdir(directory, 0700) != 0 && errno != EEXIST) return false;
    timespec now{};
    clock_gettime(CLOCK_REALTIME, &now);
    std::snprintf(g_path, sizeof(g_path), "%s/QuestCrash-%lld-%09ld-%d.txt",
                  directory, static_cast<long long>(now.tv_sec), now.tv_nsec, getpid());
    int fd = open(g_path, O_WRONLY | O_CREAT | O_EXCL | O_APPEND | O_CLOEXEC, 0600);
    if (fd < 0) return false;
    std::snprintf(g_directory, sizeof(g_directory), "%s", directory);
    char receipt[PATH_MAX + 16];
    std::snprintf(receipt, sizeof(receipt), "%s.delivered", g_path);
    g_receipt_fd.store(open(receipt, O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0600));
    g_private_fd.store(fd, std::memory_order_release);
    char header[2048];
    const int n = std::snprintf(
        header, sizeof(header),
        "QuestCrashLogger 1.0.1 (explicit MediaStore initialization)\nPackage: %s\nPID: %d\n"
        "BNM: 2.5.2 / 502928771983d29e37f28c78f28823dfb775a3aa\n"
        "Dobby: 5dfc8546954ce3b3198132ab13fddb89ee92cdd7\n"
        "This session is armed. A captured native fault appends QCL_NATIVE_CRASH below.\n"
        "The file is intentionally created before a crash so no Java calls are needed during it.\n"
        "The final report contains registers, up to 128 recent log entries, and memory maps.\n\n",
        package_name ? package_name : "unknown", getpid());
    WriteAll(fd, header, static_cast<std::size_t>(n));
    stack_t old_stack{};
    if (sigaltstack(nullptr, &old_stack) == 0 && (old_stack.ss_flags & SS_DISABLE)) {
        stack_t alternate{};
        alternate.ss_sp = g_alt_stack;
        alternate.ss_size = sizeof(g_alt_stack);
        sigaltstack(&alternate, nullptr);
    }
    unsigned installed = 0;
    struct sigaction action{};
    sigemptyset(&action.sa_mask);
    action.sa_flags = SA_SIGINFO | SA_ONSTACK;
    action.sa_sigaction = SignalHandler;
    for (unsigned i = 0; i < sizeof(kSignals) / sizeof(kSignals[0]); ++i)
        if (sigaction(kSignals[i], &action, &g_previous[i]) == 0) ++installed;
    g_ready.store(1, std::memory_order_release);
    Note(installed == sizeof(kSignals) / sizeof(kSignals[0])
             ? "Native signal handlers installed."
             : "Warning: one or more native signal handlers could not be installed.");
    return true;
}

bool NativeReady() { return g_ready.load(std::memory_order_acquire) != 0; }
const char *PrivateReportPath() { return NativeReady() ? g_path : ""; }
const char *PrivateDirectory() { return NativeReady() ? g_directory : ""; }

void SetDownloadFd(int owned_fd) {
    /* Set once, after the full existing header is copied and the row published. */
    int expected = -1;
    if (!g_download_fd.compare_exchange_strong(expected, owned_fd)) close(owned_fd);
}

void AddLog(const char *text, std::size_t length) {
    if (!text) return;
    if (length > kLineBytes) length = kLineBytes;
    const unsigned index = g_cursor.fetch_add(1, std::memory_order_acq_rel);
    Slot &slot = g_slots[index % kSlots];
    unsigned unlocked = 0;
    if (!slot.busy.compare_exchange_strong(unlocked, 1, std::memory_order_acquire)) return;
    for (unsigned j = 0; j < length; ++j)
        __atomic_store_n(&slot.bytes[j], static_cast<unsigned char>(text[j]), __ATOMIC_RELAXED);
    slot.length.store(static_cast<unsigned>(length), std::memory_order_relaxed);
    slot.sequence.store(index + 1, std::memory_order_release);
    slot.busy.store(0, std::memory_order_release);
}

void Note(const char *text) {
    const std::size_t length = std::strlen(text);
    AddLog(text, length);
    WriteAll(g_private_fd.load(), text, length);
    WriteAll(g_private_fd.load(), "\n", 1);
    const int downloads = g_download_fd.load();
    if (downloads >= 0) {
        WriteAll(downloads, text, length);
        WriteAll(downloads, "\n", 1);
    }
}

void Flush() {
    const int local = g_private_fd.load(), downloads = g_download_fd.load();
    if (local >= 0) fsync(local);
    if (downloads >= 0) fsync(downloads);
}

bool CopyReport(const char *source, int destination) {
    const int input = open(source, O_RDONLY | O_CLOEXEC);
    if (input < 0) return false;
    char buffer[16384];
    bool ok = true;
    while (true) {
        const ssize_t n = read(input, buffer, sizeof(buffer));
        if (n < 0 && errno == EINTR) continue;
        if (n == 0) break;
        if (n < 0 || !WriteAll(destination, buffer, static_cast<std::size_t>(n))) {
            ok = false;
            break;
        }
    }
    close(input);
    return ok;
}
} // namespace qcl
