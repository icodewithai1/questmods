# QuestCrashLogger 1.0.1

Android ARM64 crash logger for Meta Quest, Android API 29 and newer.
The binary is `dist/arm64-v8a/libquestcrashlogger.so`.

The startup/readiness file is named `test-<timestamp>-<nanoseconds>-<pid>.txt`
in Downloads. Its header is unchanged. If the game later crashes, crash details
append to that same pre-opened file. Recovered private crash backups keep their
`QuestCrash-…txt` names.

This revision addresses avoidable startup/export problems in 1.0.0. It has not
been tested in your game, and the original crash's cause is not established
without a device log and the game's loader details.

## What changed

- The constructor performs native setup only. It starts no worker that can
  enter Unity while the dynamic loader is initializing libraries.
- Automatic Unity hooks and arbitrary IL2CPP worker-thread attachment are removed.
  The BNM/Dobby adapter remains available through an explicit optional API.
- MediaStore initialization returns success only after creating and publishing
  a Downloads file and retaining its writable native descriptor.
- Each JNI lookup/call is checked immediately. A failure stops the operation;
  later JNI calls are not made with the exception still pending.
- Failed exports identify the failed stage through `GetLastError` and logcat.
- The provider file is opened with `w`; exporting no longer depends on forcing
  `O_APPEND` onto a provider-owned descriptor.
- The ELF uses `NODELETE`, preventing a loader's `dlclose` from unmapping active
  signal-handler/worker code. The library stays mapped until process exit.
- Intentionally ignored raised signals remain ignored.

## MediaStore and crash-time writes

The original version already used MediaStore. MediaStore is suitable for
creating/publishing the report during normal execution; it requires a working
Android Context. Its Java/Binder calls must not run inside a fatal-signal handler.

During normal initialization this revision:

1. Inserts a `text/plain` item in `MediaStore.Downloads`, initially pending.
2. Sets its relative path to `Download/QuestCrashLogs/<game.package>/`.
3. Opens a `ParcelFileDescriptor`, takes ownership of the native FD, and copies
   the current session header/private report.
4. Clears `IS_PENDING` so the report is visible, then retains the FD.

On a captured native fault the handler writes registers, cached messages, and
memory maps to that already-open FD and a private backup. It does not call Java,
MediaStore, BNM, or Dobby from the signal handler.

One small session file is therefore visible before a crash. The marker
`QCL_NATIVE_CRASH` is appended when a fatal signal is captured. Files are on the
**headset**, under shared storage `Download/QuestCrashLogs/<game.package>/`.
A file manager may label Android's `Download` directory “Downloads.”

## Initialize with the game's Android Context

A native loader that merely calls `dlopen` does **not** automatically invoke
`JNI_OnLoad`. This is a common reason a native-only mod has no Java VM/Context
and cannot initialize MediaStore.

Call the exported initializer from the game's existing JNI/loader integration:

```cpp
#include <dlfcn.h>
#include <jni.h>

// env belongs to this thread; context is the game's Application or Context.
void StartLogger(JNIEnv* env, jobject context, const char* library_path) {
    void* library = dlopen(library_path, RTLD_NOW | RTLD_LOCAL);
    if (!library) return;
    using Init = int (*)(JNIEnv*, jobject);
    using Error = const char* (*)();
    auto init = reinterpret_cast<Init>(
        dlsym(library, "QuestCrashLogger_Initialize"));
    auto error = reinterpret_cast<Error>(
        dlsym(library, "QuestCrashLogger_GetLastError"));
    if (!init || init(env, context) != 1) {
        const char* failed_stage = error ? error() : "initializer missing";
        // Log failed_stage through your loader.
        (void)failed_stage;
    }
}
```

An initializer return of **1** confirms MediaStore succeeded. Return **0** means
it did not; retry with a valid Context or resolve the reported storage/provider
error. Merely recording a JavaVM using `SetJavaVM` does not initialize Downloads.

If the game loads the library using Java `System.loadLibrary("questcrashlogger")`,
`JNI_OnLoad` receives the real VM. On that existing Java thread it tries to find
an Application, then passes a global reference to a normal MediaStore worker.
If Android restricts this Application lookup, the explicit initializer above is
required. This revision never probes private ART symbols for a guessed VM.

The session contains `MEDIASTORE_READY` once the file is published. The exported
`QuestCrashLogger_GetStatus()` has these flags:

| Flag | Value | Meaning |
| --- | --- | --- |
| `QCL_NATIVE_READY` | 1 | Private native report and signal handlers initialized |
| `QCL_DOWNLOADS_READY` | 2 | MediaStore report published and its descriptor retained |
| `QCL_UNITY_CAPTURE_READY` | 4 | Optional BNM/Dobby hook explicitly enabled |

Private reports are stored in `<Context.getFilesDir()>/QuestCrashLogger/`.
On successful Context initialization, previously undelivered native crash reports
are also retried through MediaStore. Restarting without providing a Context does
not fix missing Context initialization. Reports remain until you delete them.

## Optional BNM/Dobby capture

The same official source revisions are included:

| Dependency | Commit |
| --- | --- |
| BNM 2.5.2 | `502928771983d29e37f28c78f28823dfb775a3aa` |
| Dobby | `5dfc8546954ce3b3198132ab13fddb89ee92cdd7` |

Upstream heads were checked on 2026-11-27 UTC. The original pins and documented
Android integration fixes are preserved in `dependencies.lock.json` and
`patches/upstream-local.patch`. Official repositories:
https://github.com/ByNameModding/BNM-Android and https://github.com/jmpews/Dobby.

The shipped BNM header selector is `222` (Unity 2022.2/2022.3). To enable the
optional Unity log callback hook, the loader must first initialize MediaStore,
then call `QuestCrashLogger_EnableUnityCapture(222)` from an **already attached
IL2CPP game thread after the game finishes IL2CPP initialization**, and only
when that header configuration is appropriate for the game. It is disabled
by default to help isolate the reported startup crash.

The adapter validates MethodInfo fields, uses BNM `MethodBase` to obtain the
callback entry point, and calls `DobbyHook`. It never attaches a logger worker to
IL2CPP. Native signal capture and own-process logcat snapshots do not require
enabling this hook.

A generic `.so` cannot assume the correct loader ABI, Unity version, or loader
Context handoff for every game. A game-specific integration requires those details.

## Build and validation

On Linux with NDK r27+, CMake 3.22–3.31, and Ninja:

```bash
export ANDROID_NDK_HOME=/absolute/path/to/android-ndk-r30
bash build.sh
# Optional different BNM layout:
QCL_UNITY_VER=213 bash build.sh
```

The supplied binary uses NDK r30 / 30.0.16248370, Clang 21, CMake 3.31.10,
Android API 29, a static C++ runtime, and 16 KiB ELF load alignment. BNM and Dobby
are linked into the optional hook adapter; no separate mod runtime is needed.
Only Android system libraries are dynamically required.

```bash
python3 tests/run_native_tests.py
ANDROID_NDK_HOME=/path/to/ndk python3 tests/run_startup_tests.py
```

The 14 host signal tests cover faults, original-handler forwarding, concurrency,
private-only writes, SIGKILL's absence of a callback, and ignored-signal semantics.
The startup tests exercise the actual entry/export C++ code with strict JNI and
provider doubles: no constructor worker/hook, pending exception discipline,
10 lookup failures, failed publication/cleanup, a successful file copy, and
idempotent initialization. Those doubles do **not** test a real Android
MediaProvider or a real game's hook. Results are in `validation/`.

The user confirmed that the preceding 1.0.1 build works in their game and supplied
its `MEDIASTORE_READY` output for `com.ProjectCheetah`. This filename-only update
has been compiled and checked on the host; it has not been retested on a headset.
In particular, the
loader must supply a usable Context, and later game-installed signal handlers
can replace this logger's handlers. Load after the game's crash setup is ready.

SIGKILL, low-memory kills, power loss, and ANRs cannot run this fatal-signal
handler. Native reports include PC/SP/LR/X0–X30/PSTATE, signal details, up to
128 recent entries, and up to 256 KiB of mappings; they are not fully unwound
native backtraces or full Android tombstones. C# exception strings require the
optional hook or the game's Android log output. The alternate stack belongs to
the initialization thread; other-thread stack overflows may not be captured.

## If it still fails

Remove the 1.0.0 copy before testing this revision. Do not load both versions.
Check `GetStatus`, `GetLastError`, the private session file, and logcat tag
`QuestCrashLogger`. Include the game's name/version and native mod loader when
reporting a problem. An external ADB log can be saved even if the in-game logger
cannot initialize:

```bash
adb logcat -d -v threadtime > quest-crash.txt
```

See `include/QuestCrashLogger.h` for the C API. Dependency notices are preserved
under `third_party/`, `licenses/`, and `THIRD_PARTY_NOTICES.txt`.
